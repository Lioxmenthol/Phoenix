-ignorewarnings
-dontwarn **

# 1. Perlindungan Wajib Application, Activity, View & Provider (Anti-Force Close R8 Full Mode)
-keep class com.phoenix.tools.skin.** { *; }
-keep public class * extends android.app.Application { *; }
-keep public class * extends android.app.Activity { *; }
-keep public class * extends androidx.appcompat.app.AppCompatActivity { *; }
-keep public class * extends android.content.ContentProvider { *; }
-keep public class * extends android.view.View {
    public <init>(android.content.Context);
    public <init>(android.content.Context, android.util.AttributeSet);
    public <init>(android.content.Context, android.util.AttributeSet, int);
}

# 2. Perlindungan Wajib Unity Ads & WebView Bridge
-keepattributes SourceFile,LineNumberTable
-keepattributes JavascriptInterface
-keep class android.webkit.JavascriptInterface { *; }
-keep class com.unity3d.services.** { *; }
-keep class com.unity3d.ads.** { *; }
-keep class com.unity3d.scar.** { *; }
-keep class gatewayprotocol.** { *; }
-keep class com.iab.omid.library.unity3d.** { *; }

# 3. Perlindungan Shizuku, KProgressHUD & XBanner
-keep class com.kaopiz.kprogresshud.** { *; }
-keep class com.stx.xhb.** { *; }
-keep class dev.rikka.shizuku.** { *; }
-keep class rikka.shizuku.** { *; }
-keep class moe.shizuku.** { *; }
-keep class com.AndroidSketchwareMaster.** { *; }

# 4. Perlindungan Tambahan untuk Glide, Gson & OkHttp3
-keep public class * implements com.bumptech.glide.module.GlideModule
-keep class * extends com.bumptech.glide.module.AppGlideModule {
    <init>(...);
}
-keep public enum com.bumptech.glide.load.ImageHeaderParser$** {
    **[] $VALUES;
    public *;
}
-keepattributes Signature,EnclosingMethod,InnerClasses
-keep class com.google.gson.** { *; }
-dontwarn okhttp3.**
-dontwarn okio.**
