package com.phoenix.tools.skin;

import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.TransitionDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.unity3d.ads.IUnityAdsInitializationListener;
import com.unity3d.ads.IUnityAdsLoadListener;
import com.unity3d.ads.IUnityAdsShowListener;
import com.unity3d.ads.UnityAds;
import com.unity3d.ads.UnityAdsShowOptions;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class SplashScreenActivity extends AppCompatActivity {

    private boolean isInterstitialReady = false;
    private boolean isTransitioning = false;
    private ParticleView particleView;
    private CyberElectricView electricIconView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        android.widget.Toast.makeText(getApplicationContext(), "Mulai Init Unity...", android.widget.Toast.LENGTH_SHORT).show();
        
        try {
    UnityAds.initialize(this, "800446227", true, new IUnityAdsInitializationListener() {
        @Override
        public void onInitializationComplete() {
            runOnUiThread(() -> android.widget.Toast.makeText(getApplicationContext(), "Init Sukses! Memuat iklan...", android.widget.Toast.LENGTH_SHORT).show());
            UnityAds.load("BP_Interstitial_Android", new IUnityAdsLoadListener() {
                @Override
                public void onUnityAdsAdLoaded(String placementId) {
                    isInterstitialReady = true;
                    runOnUiThread(() -> android.widget.Toast.makeText(getApplicationContext(), "Iklan Siap!", android.widget.Toast.LENGTH_SHORT).show());
                }

                @Override
                public void onUnityAdsFailedToLoad(String placementId, UnityAds.UnityAdsLoadError error, String message) {
                    isInterstitialReady = false;
                    runOnUiThread(() -> android.widget.Toast.makeText(getApplicationContext(), "Gagal Load: " + error + " - " + message, android.widget.Toast.LENGTH_LONG).show());
                }
            });
            UnityAds.load("BP_Rewarded_Android");
        }

        @Override
        public void onInitializationFailed(UnityAds.UnityAdsInitializationError error, String message) {
            isInterstitialReady = false;
            runOnUiThread(() -> {
                new android.app.AlertDialog.Builder(SplashScreenActivity.this)
                        .setTitle("Detail Error Unity")
                        .setMessage(error + "\n\n" + message)
                        .setPositiveButton("Tutup", null)
                        .show();
            });
        }
    });
} catch (Throwable t) {
    android.widget.Toast.makeText(getApplicationContext(), "Exception Init: " + t.getMessage(), android.widget.Toast.LENGTH_LONG).show();
}


        // ================================================================
        // FULL BACKGROUND UNTUK ANDROID 10+ TANPA IMMERSIVE
        // ================================================================
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {

            getWindow().addFlags(
                    android.view.WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS
            );

            getWindow().setStatusBarColor(Color.TRANSPARENT);
            getWindow().setNavigationBarColor(Color.TRANSPARENT);

            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            );
        }

        // ================================================================
        // ANDROID 10 / API 29
        // ================================================================
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
            getWindow().setNavigationBarContrastEnforced(false);
        }

        AnehApplication.isSplashActive = true;

        final float density =
                getResources().getDisplayMetrics().density;

        // ================================================================
        // 1. ROOT FRAME CONTAINER
        // ================================================================
        final FrameLayout rootFrame = new FrameLayout(this);

        rootFrame.setBackgroundColor(
                Color.parseColor("#9E9E9E")
        );

        // ================================================================
        // 2. BACKGROUND GRADASI ABU-ABU
        // ================================================================
        LinearLayout backgroundView = new LinearLayout(this);

        FrameLayout.LayoutParams bgLp =
                new FrameLayout.LayoutParams(
                        (int) (
                                getResources()
                                        .getDisplayMetrics()
                                        .widthPixels * 1.8
                        ),
                        (int) (
                                getResources()
                                        .getDisplayMetrics()
                                        .heightPixels * 1.8
                        )
                );

        bgLp.gravity = Gravity.CENTER;

        backgroundView.setLayoutParams(bgLp);

        // ================================================================
        // WARNA AWAL
        // ================================================================
        GradientDrawable warnaAwal =
                new GradientDrawable(
                        GradientDrawable.Orientation.TL_BR,
                        new int[]{
                                Color.parseColor("#BDBDBD"),
                                Color.parseColor("#9E9E9E"),
                                Color.parseColor("#757575")
                        }
                );

        // ================================================================
        // WARNA AKHIR
        // ================================================================
        GradientDrawable warnaAkhir =
                new GradientDrawable(
                        GradientDrawable.Orientation.BR_TL,
                        new int[]{
                                Color.parseColor("#9E9E9E"),
                                Color.parseColor("#616161"),
                                Color.parseColor("#424242")
                        }
                );

        TransitionDrawable bgTransisi =
                new TransitionDrawable(
                        new GradientDrawable[]{
                                warnaAwal,
                                warnaAkhir
                        }
                );

        backgroundView.setBackground(bgTransisi);

        rootFrame.addView(backgroundView);

        // ================================================================
        // ANIMASI BACKGROUND BERPUTAR
        // ================================================================
        backgroundView.animate()
                .rotation(360f)
                .setDuration(12000)
                .setInterpolator(
                        new android.view.animation.LinearInterpolator()
                )
                .setListener(
                        new android.animation.AnimatorListenerAdapter() {

                            @Override
                            public void onAnimationEnd(
                                    android.animation.Animator animation
                            ) {

                                backgroundView.setRotation(0f);

                                backgroundView.animate()
                                        .rotation(360f)
                                        .setDuration(12000)
                                        .setInterpolator(
                                                new android.view.animation.LinearInterpolator()
                                        )
                                        .start();
                            }
                        }
                )
                .start();

        bgTransisi.startTransition(2500);

        // ================================================================
        // 3. PARTIKEL LATAR
        // ================================================================
        particleView = new ParticleView(this);

        rootFrame.addView(particleView);

        // ================================================================
        // 4. CONTAINER KONTEN UTAMA
        // ================================================================
        LinearLayout animContainer =
                new LinearLayout(this);

        animContainer.setOrientation(
                LinearLayout.VERTICAL
        );

        animContainer.setGravity(
                Gravity.CENTER
        );

        FrameLayout.LayoutParams containerLp =
                new FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT,
                        FrameLayout.LayoutParams.MATCH_PARENT
                );

        animContainer.setLayoutParams(containerLp);

        animContainer.setAlpha(0f);
        animContainer.setScaleX(0.1f);
        animContainer.setScaleY(0.1f);

        // ================================================================
        // ICON
        // ================================================================
        electricIconView =
                new CyberElectricView(this);

        LinearLayout.LayoutParams iconLp =
                new LinearLayout.LayoutParams(
                        (int) (165 * density),
                        (int) (165 * density)
                );

        electricIconView.setLayoutParams(iconLp);

        animContainer.addView(electricIconView);

        // ================================================================
        // TEXT UTAMA
        // ================================================================
        TextView introText =
                new TextView(this);

        LinearLayout.LayoutParams textLp =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                );

        textLp.topMargin =
                (int) (15 * density);

        introText.setLayoutParams(textLp);

        introText.setText(
                "Phoenix Tools Skin"
        );

        introText.setTextSize(32);

        introText.setTextColor(
                Color.BLACK
        );

        introText.setGravity(
                Gravity.CENTER
        );

        introText.setTypeface(
                Typeface.MONOSPACE,
                Typeface.BOLD
        );

        animContainer.addView(introText);

        // ================================================================
        // SUB TEXT
        // ================================================================
        TextView subIntroText =
                new TextView(this);

        LinearLayout.LayoutParams subTextLp =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                );

        subTextLp.topMargin =
                (int) (6 * density);

        subIntroText.setLayoutParams(subTextLp);

        subIntroText.setText(
                "Hero Details | Equipment Guide | WinRate Calculator"
        );

        subIntroText.setTextSize(11);

        // FIX:
        // Jangan menggunakan Color.parseColor("#BLACK")
        subIntroText.setTextColor(
                Color.BLACK
        );

        subIntroText.setGravity(
                Gravity.CENTER
        );

        subIntroText.setTypeface(
                Typeface.MONOSPACE,
                Typeface.NORMAL
        );

        animContainer.addView(subIntroText);

        rootFrame.addView(animContainer);

        // ================================================================
        // CYBER PROGRESS AREA
        // ================================================================
        LinearLayout cyberProgressArea =
                new LinearLayout(this);

        cyberProgressArea.setOrientation(
                LinearLayout.VERTICAL
        );

        cyberProgressArea.setGravity(
                Gravity.CENTER_HORIZONTAL
        );

        FrameLayout.LayoutParams progressAreaLp =
                new FrameLayout.LayoutParams(
                        (int) (260 * density),
                        FrameLayout.LayoutParams.WRAP_CONTENT
                );

        progressAreaLp.gravity =
                Gravity.BOTTOM
                | Gravity.CENTER_HORIZONTAL;

        progressAreaLp.bottomMargin =
                (int) (40 * density);

        cyberProgressArea.setLayoutParams(
                progressAreaLp
        );

        // ================================================================
        // PROGRESS TRACK
        // ================================================================
        final FrameLayout barTrackFrame = new FrameLayout(this);

        LinearLayout.LayoutParams trackLp =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        (int) (3 * density)
                );

        trackLp.bottomMargin =
                (int) (8 * density);

        barTrackFrame.setLayoutParams(trackLp);

        GradientDrawable trackDrawable =
                new GradientDrawable();

        trackDrawable.setColor(
                Color.parseColor("#559E9E9E")
        );

        trackDrawable.setCornerRadius(
                4 * density
        );

        barTrackFrame.setBackground(
                trackDrawable
        );

        // ================================================================
        // PROGRESS FILL
        // ================================================================
        View barFillView =
                new View(this);

        FrameLayout.LayoutParams fillLp =
                new FrameLayout.LayoutParams(
                        0,
                        FrameLayout.LayoutParams.MATCH_PARENT
                );

        barFillView.setLayoutParams(fillLp);

        // ================================================================
        // GRADASI PROGRESS
        // #9E9E9E SEBAGAI WARNA UTAMA
        // ================================================================
        GradientDrawable fillDrawable =
                new GradientDrawable(
                        GradientDrawable.Orientation.LEFT_RIGHT,
                        new int[]{
                                Color.parseColor("#BDBDBD"),
                                Color.parseColor("#757575"),
                                Color.parseColor("#424242")
                        }
                );

        fillDrawable.setCornerRadius(
                4 * density
        );

        barFillView.setBackground(
                fillDrawable
        );

        barTrackFrame.addView(
                barFillView
        );

        cyberProgressArea.addView(
                barTrackFrame
        );

        // ================================================================
        // LOADING TEXT
        // ================================================================
        final TextView txtLoading = new TextView(this);

        LinearLayout.LayoutParams loadingTextLp =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                );

        txtLoading.setLayoutParams(
                loadingTextLp
        );

        txtLoading.setText(
                "Connecting to server... (0%)"
        );

        txtLoading.setTextSize(11);

        txtLoading.setTextColor(
                Color.WHITE
        );

        txtLoading.setAlpha(
                0.85f
        );

        txtLoading.setTypeface(
                Typeface.MONOSPACE,
                Typeface.BOLD
        );

        cyberProgressArea.addView(
                txtLoading
        );
        
        final TextView btnNext = new TextView(this);
LinearLayout.LayoutParams btnLp = new LinearLayout.LayoutParams(
        (int) (200 * density),
        (int) (46 * density)
);
btnNext.setLayoutParams(btnLp);
btnNext.setText("NEXT  >");
btnNext.setTextSize(14);
btnNext.setTextColor(Color.WHITE);
btnNext.setGravity(Gravity.CENTER);
btnNext.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);

GradientDrawable btnBg = new GradientDrawable(
        GradientDrawable.Orientation.LEFT_RIGHT,
        new int[]{Color.parseColor("#424242"), Color.parseColor("#212121")}
);
btnBg.setCornerRadius(23 * density);
btnBg.setStroke((int) (1.5f * density), Color.parseColor("#BDBDBD"));
btnNext.setBackground(btnBg);
btnNext.setVisibility(View.GONE);
btnNext.setAlpha(0f);

btnNext.setOnTouchListener(new View.OnTouchListener() {
    @Override
    public boolean onTouch(View v, android.view.MotionEvent event) {
        if (!v.isEnabled()) return false;

        switch (event.getAction()) {
            case android.view.MotionEvent.ACTION_DOWN:
                // Animasi tenggelam saat ditekan & ditahan
                v.animate()
                        .scaleX(0.92f)
                        .scaleY(0.92f)
                        .alpha(0.8f)
                        .setDuration(100)
                        .setInterpolator(new android.view.animation.DecelerateInterpolator())
                        .start();
                return true;

            case android.view.MotionEvent.ACTION_UP:
                // Animasi kembali normal saat jari dilepas
                v.animate()
                        .scaleX(1.0f)
                        .scaleY(1.0f)
                        .alpha(1.0f)
                        .setDuration(120)
                        .setInterpolator(new android.view.animation.OvershootInterpolator(2.0f))
                        .start();

                // Jalankan logika klik hanya jika jari dilepas masih di dalam area tombol
                if (event.getX() >= 0 && event.getX() <= v.getWidth()
                        && event.getY() >= 0 && event.getY() <= v.getHeight()) {
                    
                    if (isTransitioning) return true;
                    isTransitioning = true;
                    btnNext.setEnabled(false);

                    if (isInterstitialReady) {
                        UnityAds.show(SplashScreenActivity.this, "BP_Interstitial_Android", new UnityAdsShowOptions(), new IUnityAdsShowListener() {
                            @Override
                            public void onUnityAdsShowFailure(String placementId, UnityAds.UnityAdsShowError error, String message) {
                                pindahKeMainActivity(rootFrame);
                            }
                            @Override
                            public void onUnityAdsShowStart(String placementId) {}
                            @Override
                            public void onUnityAdsShowClick(String placementId) {}
                            @Override
                            public void onUnityAdsShowComplete(String placementId, UnityAds.UnityAdsShowCompletionState state) {
                                pindahKeMainActivity(rootFrame);
                            }
                        });
                    } else {
                        pindahKeMainActivity(rootFrame);
                    }
                }
                return true;

            case android.view.MotionEvent.ACTION_CANCEL:
                // Kembalikan ukuran tombol jika sentuhan dibatalkan/digeser keluar
                v.animate()
                        .scaleX(1.0f)
                        .scaleY(1.0f)
                        .alpha(1.0f)
                        .setDuration(120)
                        .start();
                return true;
        }
        return false;
    }
});


cyberProgressArea.addView(btnNext);


        rootFrame.addView(
                cyberProgressArea
        );

        // ================================================================
        // SET CONTENT VIEW
        // ================================================================
        setContentView(rootFrame);

        // ================================================================
        // ANIMASI KONTEN MASUK
        // ================================================================
        animContainer.animate()
                .alpha(1f)
                .scaleX(1.0f)
                .scaleY(1.0f)
                .setDuration(1200)
                .setInterpolator(
                        new android.view.animation.OvershootInterpolator(2.8f)
                )
                .start();

        // ================================================================
        // 5. ENGINE DATA KINETIK REALTIME
        // ================================================================
        final int maxBarWidth =
                (int) (260 * density);

        final int[] progressVal =
                {0};

        final Random progressRandom =
                new Random();

        final String[] statusTexts = {
                "Connecting to server...",
                "Fetching resources...",
                "Optimizing asset engine...",
                "Securing gateway content...",
                "Success"
        };

        final android.os.Handler loadingHandler =
                new android.os.Handler();

        final Runnable loadingRunnable =
                new Runnable() {

                    @Override
                    public void run() {

                        if (progressVal[0] < 100) {

                            progressVal[0] +=
                                    2 + progressRandom.nextInt(7);

                            if (progressVal[0] > 100) {
                                progressVal[0] = 100;
                            }

                            // ====================================================
                            // UPDATE WIDTH PROGRESS
                            // ====================================================
                            FrameLayout.LayoutParams dynamicFill =
                                    (FrameLayout.LayoutParams)
                                            barFillView.getLayoutParams();

                            dynamicFill.width =
                                    (int) (
                                            maxBarWidth
                                            * (
                                                    progressVal[0]
                                                    / 100.0f
                                            )
                                    );

                            barFillView.setLayoutParams(
                                    dynamicFill
                            );

                            // ====================================================
                            // STATUS
                            // ====================================================
                            String currentStatus =
                                    statusTexts[0];

                            if (progressVal[0] > 20
                                    && progressVal[0] <= 50) {

                                currentStatus =
                                        statusTexts[1];

                            } else if (
                                    progressVal[0] > 50
                                    && progressVal[0] <= 75
                            ) {

                                currentStatus =
                                        statusTexts[2];

                            } else if (
                                    progressVal[0] > 75
                                    && progressVal[0] < 100
                            ) {

                                currentStatus =
                                        statusTexts[3];

                            } else if (
                                    progressVal[0] >= 100
                            ) {

                                currentStatus =
                                        statusTexts[4];
                            }

                            txtLoading.setText(
                                    currentStatus
                                    + " ("
                                    + progressVal[0]
                                    + "%)"
                            );

                            if (progressVal[0] < 100) {
    loadingHandler.postDelayed(this, 130 + progressRandom.nextInt(130));
} else {
    barTrackFrame.setVisibility(View.GONE);
    txtLoading.setVisibility(View.GONE);
    btnNext.setVisibility(View.VISIBLE);
    btnNext.animate().alpha(1f).setDuration(400).start();
}

                        }
                    }
                };

        loadingHandler.post(
                loadingRunnable
        );
    }

private void pindahKeMainActivity(final FrameLayout rootFrame) {
    runOnUiThread(new Runnable() {
        @Override
        public void run() {
            rootFrame.animate()
                    .alpha(0f)
                    .scaleX(3.0f)
                    .scaleY(3.0f)
                    .setDuration(450)
                    .setInterpolator(new android.view.animation.AccelerateInterpolator())
                    .setListener(new android.animation.AnimatorListenerAdapter() {
                        @Override
                        public void onAnimationEnd(android.animation.Animator animation) {
                            if (particleView != null) {
                                particleView.stopParticles();
                            }
                            AnehApplication.isSplashActive = false;
                            Intent intent = new Intent(SplashScreenActivity.this, MainActivity.class);
                            startActivity(intent);
                            overridePendingTransition(0, 0);
                            finish();
                        }
                    })
                    .start();
        }
    });
}

    // ====================================================================
    // CLASS INTERNAL 1
    // CYBER ELECTRIC VIEW
    // ====================================================================
    private static class CyberElectricView
            extends FrameLayout {

        private final ImageView actualLogo;

        private final Paint electricPaint =
                new Paint();

        private final Paint glowPaint =
                new Paint();

        private final Path boltPath =
                new Path();

        private final Random rand =
                new Random();

        private final float density;

        public CyberElectricView(
                Context context
        ) {

            super(context);

            setWillNotDraw(false);

            density =
                    getResources()
                            .getDisplayMetrics()
                            .density;

            // ============================================================
            // LOGO
            // ============================================================
            actualLogo =
                    new ImageView(context);

            FrameLayout.LayoutParams lp =
                    new FrameLayout.LayoutParams(
                            (int) (130 * density),
                            (int) (130 * density)
                    );

            lp.gravity =
                    Gravity.CENTER;

            actualLogo.setLayoutParams(lp);

            actualLogo.setImageResource(
                    R.drawable.phoenix
            );

            actualLogo.setScaleType(
                    ImageView.ScaleType.FIT_CENTER
            );

            addView(
                    actualLogo
            );

            // ============================================================
            // ELECTRIC
            // WARNA ABU GELAP
            // ============================================================
            electricPaint.setColor(
                    Color.parseColor("#424242")
            );

            electricPaint.setStyle(
                    Paint.Style.STROKE
            );

            electricPaint.setStrokeWidth(
                    2f * density
            );

            electricPaint.setAntiAlias(
                    true
            );

            // ============================================================
            // GLOW
            // WARNA SELARAS #9E9E9E
            // ============================================================
            glowPaint.setColor(
                    Color.parseColor("#BDBDBD")
            );

            glowPaint.setStyle(
                    Paint.Style.STROKE
            );

            glowPaint.setStrokeWidth(
                    5f * density
            );

            glowPaint.setAlpha(
                    150
            );

            glowPaint.setAntiAlias(
                    true
            );
        }

        @Override
        protected void onDraw(
                Canvas canvas
        ) {

            super.onDraw(
                    canvas
            );

            float cx =
                    getWidth() / 2f;

            float cy =
                    getHeight() / 2f;

            float radius =
                    (130 * density) / 2f;

            // ============================================================
            // 3 LAYER ELECTRIC
            // ============================================================
            for (int i = 0; i < 3; i++) {

                generateCircularLightning(
                        cx,
                        cy,
                        radius
                );

                canvas.drawPath(
                        boltPath,
                        glowPaint
                );

                canvas.drawPath(
                        boltPath,
                        electricPaint
                );
            }

            invalidate();
        }

        private void generateCircularLightning(
                float cx,
                float cy,
                float r
        ) {

            boltPath.reset();

            int points =
                    24;

            float angleStep =
                    (float)
                            (
                                    2 * Math.PI
                                    / points
                            );

            for (
                    int i = 0;
                    i <= points;
                    i++
            ) {

                float currentAngle =
                        i * angleStep;

                float offset =
                        -8 * density
                        + rand.nextFloat()
                        * (16 * density);

                float dynamicRadius =
                        r + offset;

                float x =
                        cx
                        + (float)
                        (
                                Math.cos(currentAngle)
                                * dynamicRadius
                        );

                float y =
                        cy
                        + (float)
                        (
                                Math.sin(currentAngle)
                                * dynamicRadius
                        );

                if (i == 0) {

                    boltPath.moveTo(
                            x,
                            y
                    );

                } else {

                    boltPath.lineTo(
                            x,
                            y
                    );
                }
            }

            boltPath.close();
        }
    }

    // ====================================================================
    // CLASS INTERNAL 2
    // PARTICLE VIEW
    // ====================================================================
    private static class ParticleView
            extends View {

        private final List<Particle> particles =
                new ArrayList<>();

        private final Random random =
                new Random();

        private final Paint paint =
                new Paint();

        private boolean isRunning =
                true;

        public ParticleView(
                Context context
        ) {

            super(context);

            paint.setAntiAlias(
                    true
            );

            // ============================================================
            // 35 PARTICLES
            // ============================================================
            for (
                    int i = 0;
                    i < 35;
                    i++
            ) {

                particles.add(
                        new Particle()
                );
            }
        }

        @Override
        protected void onDraw(
                Canvas canvas
        ) {

            super.onDraw(
                    canvas
            );

            if (!isRunning) {
                return;
            }

            int width =
                    getWidth();

            int height =
                    getHeight();

            if (
                    width == 0
                    || height == 0
            ) {

                invalidate();

                return;
            }

            for (Particle p : particles) {

                p.update(
                        width,
                        height,
                        random
                );

                paint.setColor(
                        p.color
                );

                paint.setAlpha(
                        p.alpha
                );

                canvas.drawCircle(
                        p.x,
                        p.y,
                        p.radius,
                        paint
                );
            }

            invalidate();
        }

        public void stopParticles() {

            isRunning =
                    false;

            particles.clear();
        }

        // ================================================================
        // PARTICLE
        // ================================================================
        private static class Particle {

            float x;
            float y;
            float radius;
            float speedX;
            float speedY;

            int color;
            int alpha;

            void update(
                    int width,
                    int height,
                    Random r
            ) {

                if (
                        radius == 0
                        || x < 0
                        || x > width
                        || y < 0
                        || y > height
                        || alpha <= 0
                ) {

                    x =
                            r.nextInt(width);

                    y =
                            r.nextInt(height);

                    radius =
                            2
                            + r.nextFloat() * 5;

                    speedX =
                            -1.2f
                            + r.nextFloat() * 2.4f;

                    speedY =
                            -1.5f
                            + r.nextFloat() * 1.5f;

                    alpha =
                            60
                            + r.nextInt(160);

                    // ====================================================
                    // WARNA PARTICLE SELARAS DENGAN #9E9E9E
                    // ====================================================
                    int colorType =
                            r.nextInt(4);

                    if (colorType == 0) {

                        colorColor(
                                Color.parseColor(
                                        "#424242"
                                )
                        );

                    } else if (colorType == 1) {

                        colorColor(
                                Color.parseColor(
                                        "#616161"
                                )
                        );

                    } else if (colorType == 2) {

                        colorColor(
                                Color.parseColor(
                                        "#BDBDBD"
                                )
                        );

                    } else {

                        colorColor(
                                Color.WHITE
                        );
                    }

                } else {

                    x += speedX;

                    y += speedY;

                    alpha -= 1;
                }
            }

            private void colorColor(
                    int c
            ) {

                this.color =
                        c;
            }
        }
    }
}