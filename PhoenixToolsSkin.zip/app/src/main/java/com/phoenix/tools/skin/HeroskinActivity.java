package com.phoenix.tools.skin;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.documentfile.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.*;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import androidx.startup.*;
import com.AndroidSketchwareMaster.*;
import com.AndroidSketchwareMaster.ShizukuMaster;
import com.AndroidSketchwareMaster.ShizukuShell;
import com.AndroidSketchwareMaster.ShizukuShell.OnProcessCompleteListener;
import com.android.volley.*;
import com.kaopiz.kprogresshud.*;
import com.stx.xhb.androidx.*;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;
import rikka.shizuku.Shizuku;
import java.util.HashMap;
import java.io.*;
import java.util.zip.*;
import android.database.*;
import androidx.annotation.NonNull;

import com.google.android.material.snackbar.Snackbar;

import androidx.core.widget.NestedScrollView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import androidx.core.content.ContextCompat;
import android.graphics.Typeface;
import android.view.View;
import android.widget.TextView;

import android.provider.Settings;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;

import java.net.NetworkInterface;
import java.util.Collections;
import java.lang.Process;

import com.phoenix.tools.skin.security.JsonManager;

/* ====== TAMBAHAN UNTUK DOWNLOAD ANDROID 10+ ====== */
import android.provider.MediaStore;
import android.content.ContentValues;
import android.content.ContentResolver;
import android.net.Uri;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.BitmapDrawable;
import android.view.Gravity;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.bumptech.glide.request.RequestOptions;

public class HeroskinActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	private String files = "";
	private String Npath1 = "";
	private String Npath = "";
	PermissionManager perm;
	String fileNameGlobal;
	long downloadId;
	ProgressDialog progressDialog;
	
	private ArrayList<HashMap<String, Object>> lmap = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> listDetailHero = new ArrayList<>();
	
	private LinearLayout linear2;
	private LinearLayout linear3;
	private RecyclerView recyclerview1;
	private ImageView imageview1;
	private TextView textview2;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private ImageView imageview3;
	
	private SharedPreferences sp;
	private Intent i = new Intent();
	private RequestNetwork baby;
	private RequestNetwork.RequestListener _baby_request_listener;
	private TimerTask d;
	private SharedPreferences aneh;
	private SharedPreferences down;
	private TimerTask tomer;
	private AlertDialog.Builder dialog;
	private ShizukuMaster fyy;
	private RequestNetwork networkDetail;
	private RequestNetwork.RequestListener _networkDetail_request_listener;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.heroskin);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear2 = findViewById(R.id.linear2);
		linear3 = findViewById(R.id.linear3);
		recyclerview1 = findViewById(R.id.recyclerview1);
		imageview1 = findViewById(R.id.imageview1);
		textview2 = findViewById(R.id.textview2);
		linear4 = findViewById(R.id.linear4);
		linear5 = findViewById(R.id.linear5);
		imageview3 = findViewById(R.id.imageview3);
		sp = getSharedPreferences("sp", Activity.MODE_PRIVATE);
		baby = new RequestNetwork(this);
		aneh = getSharedPreferences("aneh", Activity.MODE_PRIVATE);
		down = getSharedPreferences("down", Activity.MODE_PRIVATE);
		dialog = new AlertDialog.Builder(this);
		networkDetail = new RequestNetwork(this);
		
		_baby_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				SharedPreferences cache =
				getSharedPreferences("JSON_CACHE", MODE_PRIVATE);
				
				String oldJson =
				cache.getString("ml", "");
				
				// ========================================================
				// 💾 SIMPAN CACHE GLOBAL HANYA JIKA BERUBAH
				// ========================================================
				if (!_response.equals(oldJson)) {
					
					cache.edit()
					.putString("ml", _response)
					.apply();
				}
				
				// ========================================================
				// 📦 PARSE JSON
				// ========================================================
				HashMap<String, HashMap<String, Object>> map =
				new Gson().fromJson(
				_response,
				new TypeToken<HashMap<String, HashMap<String, Object>>>(){}.getType()
				);
				
				if (map == null || map.size() == 0) {
					return;
				}
				
				// ========================================================
				// 🔎 FILTER DATA SESUAI HERO
				// ========================================================
				ArrayList<HashMap<String, Object>> just4 =
				new ArrayList<>();
				
				for (String key : map.keySet()) {
					
					HashMap<String, Object> heroData =
					map.get(key);
					
					if (heroData != null &&
					heroData.containsKey("hero") &&
					heroData.get("hero").toString().equals(
					sp.getString("her", "")
					)) {
						
						HashMap<String, Object> m =
						new HashMap<>();
						
						m.put("skin_name", heroData.get("skin_name"));
						m.put("img", heroData.get("img"));
						m.put("img2", heroData.get("img2"));
						m.put("url", heroData.get("url"));
						m.put("sort", heroData.get("sort"));
						
						just4.add(m);
					}
				}
				
				if (just4.size() == 0) {
					return;
				}
				
				// ========================================================
				// 🔥 SORT UTAMA BERDASARKAN SORT
				// ========================================================
				_AnehGamingOfficial(just4, "sort");
				
				// ========================================================
				// 🔥 URUTAN FINAL
				// ORI → NORMAL A-Z → " to " A-Z
				// ========================================================
				if (just4.size() > 1) {
					
					ArrayList<HashMap<String, Object>> oriList =
					new ArrayList<>();
					
					ArrayList<HashMap<String, Object>> normalList =
					new ArrayList<>();
					
					ArrayList<HashMap<String, Object>> targetList =
					new ArrayList<>();
					
					// ====================================================
					// 1. KUNCI ITEM PERTAMA SEBAGAI SKIN ORI
					// ====================================================
					oriList.add(just4.get(0));
					
					// ====================================================
					// 2. PISAHKAN NORMAL DAN " to "
					// ====================================================
					for (int i = 1; i < just4.size(); i++) {
						
						HashMap<String, Object> item =
						just4.get(i);
						
						if (item == null) {
							continue;
						}
						
						// Jangan masukkan data hantu di bagian ini
						if ("true".equals(
						String.valueOf(item.get("is_data_hantu"))
						)) {
							continue;
						}
						
						if (item.containsKey("skin_name") &&
						item.get("skin_name") != null) {
							
							String skinName =
							String.valueOf(item.get("skin_name"));
							
							// =================================================
							// SKIN MENGANDUNG " to "
							// =================================================
							if (skinName.toLowerCase().contains(" to ")) {
								
								targetList.add(item);
								
							} else {
								
								// =================================================
								// SKIN NORMAL
								// =================================================
								normalList.add(item);
							}
							
						} else {
							
							normalList.add(item);
						}
					}
					
					// ====================================================
					// 3. NORMAL A-Z
					// ====================================================
					java.util.Collections.sort(
					normalList,
					(o1, o2) -> {
						
						String name1 =
						String.valueOf(
						o1.get("skin_name") != null
						? o1.get("skin_name")
						: ""
						);
						
						String name2 =
						String.valueOf(
						o2.get("skin_name") != null
						? o2.get("skin_name")
						: ""
						);
						
						return name1.compareToIgnoreCase(name2);
					}
					);
					
					// ====================================================
					// 4. " to " A-Z
					// ====================================================
					java.util.Collections.sort(
					targetList,
					(o1, o2) -> {
						
						String name1 =
						String.valueOf(
						o1.get("skin_name") != null
						? o1.get("skin_name")
						: ""
						);
						
						String name2 =
						String.valueOf(
						o2.get("skin_name") != null
						? o2.get("skin_name")
						: ""
						);
						
						return name1.compareToIgnoreCase(name2);
					}
					);
					
					// ====================================================
					// 5. GABUNGKAN KEMBALI
					// ====================================================
					just4.clear();
					
					// SKIN ORI
					just4.addAll(oriList);
					
					// SKIN NORMAL A-Z
					just4.addAll(normalList);
					
					// SKIN " to " PALING BAWAH
					just4.addAll(targetList);
				}
				
				// ========================================================
				// 🔎 CEK DETAIL HERO GITHUB COCOK
				// ========================================================
				String heroTerpilih_onResponseUtama =
				sp.getString("her", "");
				
				boolean adaDetailHeroOnline = false;
				
				if (listDetailHero != null &&
				!listDetailHero.isEmpty() &&
				!heroTerpilih_onResponseUtama.isEmpty()) {
					
					for (int i = 0; i < listDetailHero.size(); i++) {
						
						java.util.HashMap<String, Object> tempHero =
						listDetailHero.get(i);
						
						if (tempHero.containsKey("her") &&
						String.valueOf(
						tempHero.get("her")
						).equalsIgnoreCase(
						heroTerpilih_onResponseUtama
						)) {
							
							adaDetailHeroOnline = true;
							break;
						}
					}
				}
				
				// ========================================================
				// 👻 TAMBAHKAN DATA HANTU PALING AKHIR
				// ========================================================
				if (adaDetailHeroOnline &&
				just4 != null &&
				!just4.isEmpty()) {
					
					java.util.HashMap<String, Object> dataHantuTiruan =
					new java.util.HashMap<>();
					
					dataHantuTiruan.put(
					"is_data_hantu",
					"true"
					);
					
					dataHantuTiruan.put(
					"skin_name",
					"DataHantuPembukaSlot"
					);
					
					just4.add(dataHantuTiruan);
				}
				
				// ========================================================
				// 💾 SIMPAN CACHE HERO SPESIFIK
				// ========================================================
				String jsonFinalHero =
				new Gson().toJson(just4);
				
				sp.edit()
				.putString(
				"cache_skin_" +
				heroTerpilih_onResponseUtama,
				jsonFinalHero
				)
				.apply();
				
				// ========================================================
				// 📍 SIMPAN POSISI SCROLL
				// ========================================================
				int posisiScrollTerakhir = 0;
				int topOffset = 0;
				
				androidx.recyclerview.widget.GridLayoutManager
				layoutManager_kustom = null;
				
				if (recyclerview1 != null &&
				recyclerview1.getLayoutManager()
				instanceof androidx.recyclerview.widget.GridLayoutManager) {
					
					layoutManager_kustom =
					(androidx.recyclerview.widget.GridLayoutManager)
					recyclerview1.getLayoutManager();
					
					posisiScrollTerakhir =
					layoutManager_kustom.findFirstVisibleItemPosition();
					
					View viewTeratas =
					layoutManager_kustom.findViewByPosition(
					posisiScrollTerakhir
					);
					
					topOffset =
					(viewTeratas == null)
					? 0
					: (
					viewTeratas.getTop() -
					recyclerview1.getPaddingTop()
					);
				}
				
				// ========================================================
				// 📱 TAMPILKAN KE RECYCLERVIEW
				// ========================================================
				if (recyclerview1 != null) {
					
					recyclerview1.setAdapter(
					new Recyclerview1Adapter(just4)
					);
					
					recyclerview1.setAlpha(1f);
					
					if (layoutManager_kustom != null &&
					posisiScrollTerakhir > 0) {
						
						layoutManager_kustom.scrollToPositionWithOffset(
						posisiScrollTerakhir,
						topOffset
						);
					}
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_networkDetail_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				try {
					// 🚀 1. Simpan teks respon internet ke SharedPreferences sebagai cache offline!
					sp.edit().putString("cache_detail_hero", _response).apply();
					
					// 2. Ambil data teks response internet detail hero dari GitHub
					listDetailHero = new com.google.gson.Gson().fromJson(
					_response, 
					new com.google.gson.reflect.TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType()
					);
					
					// 3. REFRESH ADAPTER UNIVERSAL DENGAN PEREKAM KOORDINAT SCROLL (ANTI-MELOMPAT!)
					try {
						if (recyclerview1 != null && recyclerview1.getLayoutManager() != null) {
							// Ambil LayoutManager secara dinamis lewat refleksi atau casting aman
							androidx.recyclerview.widget.GridLayoutManager layoutManager_kustom = null;
							if (recyclerview1.getLayoutManager() instanceof androidx.recyclerview.widget.GridLayoutManager) {
								layoutManager_kustom = (androidx.recyclerview.widget.GridLayoutManager) recyclerview1.getLayoutManager();
							}
							
							int posisiScrollTerakhir = 0;
							int topOffset = 0;
							
							// Rekam posisi koordinat baris dan pixel offset saat ini sebelum data disegarkan
							if (layoutManager_kustom != null) {
								posisiScrollTerakhir = layoutManager_kustom.findFirstVisibleItemPosition();
								View viewTeratas = layoutManager_kustom.findViewByPosition(posisiScrollTerakhir);
								topOffset = (viewTeratas == null) ? 0 : (viewTeratas.getTop() - recyclerview1.getPaddingTop());
							}
							
							// Eksekusi notifyDataSetChanged bawaan kodemu
							Object adapterObj_kustom = recyclerview1.getClass().getMethod("getAdapter").invoke(recyclerview1);
							if (adapterObj_kustom != null) {
								adapterObj_kustom.getClass().getMethod("notifyDataSetChanged").invoke(adapterObj_kustom);
								
								// 🚀 KUNCI SAKTI: Kembalikan posisi pandangan user secara instan (ANTI-LOMPAT!)
								if (layoutManager_kustom != null && posisiScrollTerakhir > 0) {
									layoutManager_kustom.scrollToPositionWithOffset(posisiScrollTerakhir, topOffset);
								}
							}
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
					
				} catch (Exception e) {
					android.widget.Toast.makeText(getApplicationContext(), "Gagal menyelaraskan data detail!", android.widget.Toast.LENGTH_SHORT).show();
				}
				
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
	}
	
	private void initializeLogic() {
		DialogUtil.applySecureEdgeToEdge(this);
		
		ZeroAdsManager.loadAd(getApplicationContext());
		
		// ========================================================
		// 🚀 STEP 1: TAMENG OFFLINE SAKTI DI BARIS PALING ATAS
		// ========================================================
		String cacheLokal = sp.getString("cache_detail_hero", "");
		if (!cacheLokal.isEmpty()) {
			try {
				listDetailHero = new com.google.gson.Gson().fromJson(
				cacheLokal, 
				new com.google.gson.reflect.TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType()
				);
			} catch(Exception e) {}
		}
		
		// ========================================================
		// 🚀 STEP 1.5: PENGUNCI FOKUS SAKTI OTOMATIS (ANTI-MELOMPAT KE ATAS)
		// ========================================================
		try {
			android.view.ViewGroup indukOtomatis = (android.view.ViewGroup) recyclerview1.getParent();
			if (indukOtomatis != null) {
				indukOtomatis.setFocusable(true);
				indukOtomatis.setFocusableInTouchMode(true);
				indukOtomatis.setDescendantFocusability(android.view.ViewGroup.FOCUS_BLOCK_DESCENDANTS);
			}
		} catch (Exception e) {}
		
		if (recyclerview1 != null) {
			recyclerview1.setFocusable(false);
			recyclerview1.setFocusableInTouchMode(false);
		}
		
		// ========================================================
		// 🚀 STEP 2: PENYELAMAT CRASH & ANTI-KEDIP SCROLL
		// ========================================================
		if (recyclerview1.getItemAnimator() != null) {
			recyclerview1.setItemAnimator(null); 
		}
		
		android.view.LayoutInflater inflater_kustom = (android.view.LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		final View headerView_kustom = inflater_kustom.inflate(R.layout.herodetail, null);
		
		recyclerview1.setTag(R.id.imageview2, headerView_kustom);
		
		androidx.recyclerview.widget.GridLayoutManager layoutManager = new androidx.recyclerview.widget.GridLayoutManager(HeroskinActivity.this, 3);
		
		layoutManager.setSpanSizeLookup(new androidx.recyclerview.widget.GridLayoutManager.SpanSizeLookup() {
			@Override
			public int getSpanSize(int position) {
				return (position == 0) ? 3 : 1;
			}
		});
		recyclerview1.setLayoutManager(layoutManager);
		
		// ========================================================
		// 🚀 STEP 3: SISTEM SINGKRONISASI REFRESH DENGAN PEREKAM KOORDINAT
		// ========================================================
		try {
			recyclerview1.getViewTreeObserver().addOnGlobalLayoutListener(new android.view.ViewTreeObserver.OnGlobalLayoutListener() {
				@Override
				public void onGlobalLayout() {
					// Hapus listener SEGERA di baris pertama agar TIDAK TERJADI LOOPING RENDER ULANG
					if (recyclerview1.getViewTreeObserver().isAlive()) {
						recyclerview1.getViewTreeObserver().removeOnGlobalLayoutListener(this);
					}
					
					boolean adaDetail = false;
					String heroTerpilih_onCreate = sp.getString("her", "");
					if (listDetailHero != null && !listDetailHero.isEmpty() && !heroTerpilih_onCreate.isEmpty()) {
						for (int i = 0; i < listDetailHero.size(); i++) {
							java.util.HashMap<String, Object> temp = listDetailHero.get(i);
							if (temp.containsKey("her") && String.valueOf(temp.get("her")).equalsIgnoreCase(heroTerpilih_onCreate)) {
								adaDetail = true; 
								break;
							}
						}
					}
					
					// JIKA ADA DETAIL, REFRESH DENGAN REKAMAN POSISI AGAR TIDAK MENTAL KE ATAS SAAT BARU BUKA
					if (adaDetail && recyclerview1.getAdapter() != null && recyclerview1.getLayoutManager() instanceof androidx.recyclerview.widget.GridLayoutManager) {
						androidx.recyclerview.widget.GridLayoutManager lm = (androidx.recyclerview.widget.GridLayoutManager) recyclerview1.getLayoutManager();
						
						// 🚀 REKAM KOORDINAT AWAL SEBELUM REFRESH DATA CACHE LOKAL
						int posScroll = lm.findFirstVisibleItemPosition();
						View vAtas = lm.findViewByPosition(posScroll);
						int offset = (vAtas == null) ? 0 : (vAtas.getTop() - recyclerview1.getPaddingTop());
						
						recyclerview1.getAdapter().notifyDataSetChanged();
						
						// Kembalikan posisi scroll user secara paksa (ANTI-LOMPAT!)
						if (posScroll > 0) {
							lm.scrollToPositionWithOffset(posScroll, offset);
						}
					}
				}
			});
		} catch(Exception e) {}
		
		// ========================================================
		// 🚀 STEP 4: MENARIK DATA TERBARU DARI GITHUB (ONLINE PENYELARAS)
		// ========================================================
		String urlDetailHero = "https://lioxmenthol.github.io/Detail-hero/detail_hero.json";
		networkDetail.startRequestNetwork("GET", urlDetailHero, "B", _networkDetail_request_listener);
		
		textview2.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 19);
		textview2.setText(sp.getString("her", ""));
		
		// ========================================================
		// 🚀 TAMENG SAKTI UTAMA: KUNCI FOKUS LAYOUT AUTOMATIS
		// ========================================================
		try {
			android.view.ViewGroup indukOtomatis =
			(android.view.ViewGroup) recyclerview1.getParent();
			
			if (indukOtomatis != null) {
				indukOtomatis.setFocusable(true);
				indukOtomatis.setFocusableInTouchMode(true);
				indukOtomatis.setDescendantFocusability(
				android.view.ViewGroup.FOCUS_BLOCK_DESCENDANTS
				);
			}
		} catch (Exception e) {}
		
		if (recyclerview1 != null) {
			recyclerview1.setFocusable(false);
			recyclerview1.setFocusableInTouchMode(false);
		}
		
		// ========================================================
		// 🚀 LOAD CACHE KUSTOM PER HERO
		// ========================================================
		String namaHero_onCreate = sp.getString("her", "");
		String cacheSkinKustom =
		sp.getString("cache_skin_" + namaHero_onCreate, "");
		
		if (!cacheSkinKustom.isEmpty()) {
			
			try {
				
				ArrayList<HashMap<String, Object>> dataMatangCache =
				new Gson().fromJson(
				cacheSkinKustom,
				new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType()
				);
				
				if (dataMatangCache != null &&
				dataMatangCache.size() > 0) {
					
					// =================================================
					// 🔥 SORTING SAMA DENGAN ONRESPONSE
					// ORI → NORMAL A-Z → " to " A-Z
					// =================================================
					
					if (dataMatangCache.size() > 1) {
						
						ArrayList<HashMap<String, Object>> oriList =
						new ArrayList<>();
						
						ArrayList<HashMap<String, Object>> normalList =
						new ArrayList<>();
						
						ArrayList<HashMap<String, Object>> targetList =
						new ArrayList<>();
						
						// ------------------------------------------------
						// ITEM PERTAMA = SKIN ORI
						// ------------------------------------------------
						oriList.add(dataMatangCache.get(0));
						
						// ------------------------------------------------
						// PISAHKAN NORMAL DAN " to "
						// ------------------------------------------------
						for (int i = 1; i < dataMatangCache.size(); i++) {
							
							HashMap<String, Object> item =
							dataMatangCache.get(i);
							
							if (item == null) {
								continue;
							}
							
							// Data hantu jangan ikut sorting
							if ("true".equals(
							String.valueOf(item.get("is_data_hantu"))
							)) {
								continue;
							}
							
							if (item.containsKey("skin_name") &&
							item.get("skin_name") != null) {
								
								String skinName =
								String.valueOf(item.get("skin_name"));
								
								if (skinName.toLowerCase().contains(" to ")) {
									
									targetList.add(item);
									
								} else {
									
									normalList.add(item);
								}
								
							} else {
								
								normalList.add(item);
							}
						}
						
						// ------------------------------------------------
						// NORMAL A-Z
						// ------------------------------------------------
						java.util.Collections.sort(
						normalList,
						(o1, o2) -> {
							
							String name1 =
							String.valueOf(
							o1.get("skin_name") != null
							? o1.get("skin_name")
							: ""
							);
							
							String name2 =
							String.valueOf(
							o2.get("skin_name") != null
							? o2.get("skin_name")
							: ""
							);
							
							return name1.compareToIgnoreCase(name2);
						}
						);
						
						// ------------------------------------------------
						// " to " A-Z
						// ------------------------------------------------
						java.util.Collections.sort(
						targetList,
						(o1, o2) -> {
							
							String name1 =
							String.valueOf(
							o1.get("skin_name") != null
							? o1.get("skin_name")
							: ""
							);
							
							String name2 =
							String.valueOf(
							o2.get("skin_name") != null
							? o2.get("skin_name")
							: ""
							);
							
							return name1.compareToIgnoreCase(name2);
						}
						);
						
						// ------------------------------------------------
						// GABUNGKAN
						// ------------------------------------------------
						dataMatangCache.clear();
						
						dataMatangCache.addAll(oriList);
						dataMatangCache.addAll(normalList);
						dataMatangCache.addAll(targetList);
					}
					
					// =================================================
					// TAMPILKAN CACHE
					// =================================================
					if (recyclerview1 != null) {
						
						recyclerview1.setAlpha(0f);
						
						recyclerview1.setAdapter(
						new Recyclerview1Adapter(dataMatangCache)
						);
						
						recyclerview1.animate()
						.alpha(1f)
						.setDuration(180)
						.start();
					}
				}
				
			} catch (Exception e) {}
			
		} else {
			
			// ========================================================
			// BACKUP SYSTEM: JSON_CACHE GLOBAL
			// ========================================================
			SharedPreferences cache =
			getSharedPreferences("JSON_CACHE", MODE_PRIVATE);
			
			String json =
			cache.getString("ml", null);
			
			if (json != null) {
				
				HashMap<String, HashMap<String, Object>> map =
				new Gson().fromJson(
				json,
				new TypeToken<HashMap<String, HashMap<String, Object>>>(){}.getType()
				);
				
				if (map != null && map.size() > 0) {
					
					ArrayList<HashMap<String, Object>> just4 =
					new ArrayList<>();
					
					for (String key : map.keySet()) {
						
						HashMap<String, Object> heroData =
						map.get(key);
						
						if (heroData != null &&
						heroData.containsKey("hero") &&
						heroData.get("hero").toString().equals(
						sp.getString("her", "")
						)) {
							
							HashMap<String, Object> m =
							new HashMap<>();
							
							m.put("skin_name", heroData.get("skin_name"));
							m.put("img", heroData.get("img"));
							m.put("img2", heroData.get("img2"));
							m.put("url", heroData.get("url"));
							m.put("sort", heroData.get("sort"));
							
							just4.add(m);
						}
					}
					
					if (just4.size() > 0) {
						
						// =================================================
						// SORT UTAMA
						// =================================================
						_AnehGamingOfficial(just4, "sort");
						
						// =================================================
						// 🔥 ORI → NORMAL A-Z → " to " A-Z
						// =================================================
						if (just4.size() > 1) {
							
							ArrayList<HashMap<String, Object>> oriList =
							new ArrayList<>();
							
							ArrayList<HashMap<String, Object>> normalList =
							new ArrayList<>();
							
							ArrayList<HashMap<String, Object>> targetList =
							new ArrayList<>();
							
							// ITEM PERTAMA = ORI
							oriList.add(just4.get(0));
							
							// PISAHKAN SISANYA
							for (int i = 1; i < just4.size(); i++) {
								
								HashMap<String, Object> item =
								just4.get(i);
								
								if (item == null) {
									continue;
								}
								
								if (item.containsKey("skin_name") &&
								item.get("skin_name") != null) {
									
									String skinName =
									String.valueOf(item.get("skin_name"));
									
									if (skinName.toLowerCase().contains(" to ")) {
										
										targetList.add(item);
										
									} else {
										
										normalList.add(item);
									}
									
								} else {
									
									normalList.add(item);
								}
							}
							
							// NORMAL A-Z
							java.util.Collections.sort(
							normalList,
							(o1, o2) -> {
								
								String name1 =
								String.valueOf(
								o1.get("skin_name") != null
								? o1.get("skin_name")
								: ""
								);
								
								String name2 =
								String.valueOf(
								o2.get("skin_name") != null
								? o2.get("skin_name")
								: ""
								);
								
								return name1.compareToIgnoreCase(name2);
							}
							);
							
							// " to " A-Z
							java.util.Collections.sort(
							targetList,
							(o1, o2) -> {
								
								String name1 =
								String.valueOf(
								o1.get("skin_name") != null
								? o1.get("skin_name")
								: ""
								);
								
								String name2 =
								String.valueOf(
								o2.get("skin_name") != null
								? o2.get("skin_name")
								: ""
								);
								
								return name1.compareToIgnoreCase(name2);
							}
							);
							
							// GABUNG
							just4.clear();
							
							just4.addAll(oriList);
							just4.addAll(normalList);
							just4.addAll(targetList);
						}
						
						// =================================================
						// TAMPILKAN
						// =================================================
						if (recyclerview1 != null) {
							
							recyclerview1.setAlpha(0f);
							
							recyclerview1.setAdapter(
							new Recyclerview1Adapter(just4)
							);
							
							recyclerview1.animate()
							.alpha(1f)
							.setDuration(180)
							.start();
						}
					}
				}
			}
		}
		
		// ========================================================
		// 🌐 REQUEST NETWORK SELALU UNTUK UPDATE
		// ========================================================
		String url = JsonManager.getJsonUrl("ml");
		
		baby.startRequestNetwork(
		RequestNetworkController.GET,
		url,
		"AnehGamingKey",
		_baby_request_listener
		);
		
		// ========================================================
		// 🛡️ SAKLAR OTOMATIS
		// ========================================================
		com.phoenix.tools.skin.security.JsonManager.checkSkinSwitch(this);
		textview2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/quick.ttf"), 3);
		imageview1.setOnTouchListener(new View.OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				switch (event.getAction()) {
					case MotionEvent.ACTION_DOWN:
					v.animate().scaleX(0.7f).scaleY(0.7f).setDuration(100).start();
					break;
					case MotionEvent.ACTION_UP:
					case MotionEvent.ACTION_CANCEL:
					v.animate().scaleX(1f).scaleY(1f).setDuration(100).start();
					break;
				}
				return false;
			}
		});
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				finish(); // 🔥 INI KUNCINYA
			}
		});
		
		// ---------------------
		imageview3.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
				// =========================
				// ANIMASI
				// =========================
				v.animate()
				.scaleX(0.8f)
				.scaleY(0.8f)
				.setDuration(100)
				.withEndAction(new Runnable() {
					
					@Override
					public void run() {
						
						v.animate()
						.scaleX(1f)
						.scaleY(1f)
						.setDuration(100)
						.start();
						
						final float density =
						getResources()
						.getDisplayMetrics()
						.density;
						
						// =========================
						// LAYOUT
						// =========================
						LinearLayout layout =
						new LinearLayout(
						HeroskinActivity.this
						);
						
						layout.setOrientation(
						LinearLayout.VERTICAL
						);
						
						layout.setPadding(
						40,
						40,
						40,
						30
						);
						
						ScrollView scrollView =
						new ScrollView(
						HeroskinActivity.this
						);
						
						TextView message =
						new TextView(
						HeroskinActivity.this
						);
						
						message.setText(
						"⚠️ INFORMASI & SANGGAHAN (HERO GUIDE DISCLAIMER):\n" +
						"Halaman ini menyajikan informasi referensi, statistik teoretis, simulasi strategi, dan kalkulasi atribut hero yang bertujuan untuk edukasi komunitas penggemar (Unofficial Fan-made Encyclopedia).\n\n" +
						"Seluruh nama karakter, model visual, gambar ikon, lore cerita, dan hak kekayaan intelektual terkait hero yang ditampilkan adalah hak cipta dan milik sepenuhnya dari pemilik sah merek dagang game asli.\n\n" +
						"Aplikasi ini SAMA SEKALI TIDAK memodifikasi, memanipulasi, atau menginterferensi data game asli dalam bentuk apa pun. Data statistik dapat berubah sewaktu-waktu mengikuti penyesuaian keseimbangan (patch update) pada versi game resmi." +
						"\n----------------------------------------\n" +
						"⚠️ INFORMATION & LEGAL DISCLAIMER (HERO GUIDE):\n" +
						"This page provides reference information, theoretical statistics, strategy simulation, and hero attribute calculations intended for community educational purposes (Unofficial Fan-made Encyclopedia).\n\n" +
						"All character names, visual models, icon images, lore, and related intellectual property of the heroes displayed are the exclusive copyrights and trademarks of their respective owners.\n\n" +
						"This application DOES NOT modify, manipulate, or interfere with official game data in any way. Statistical data is subject to change at any time following balance adjustments (patch updates) in the official game version."
						);
						
						
						message.setTextSize(14);
						
						message.setTextColor(
						Color.WHITE
						);
						
						message.setTypeface(
						Typeface.DEFAULT_BOLD
						);
						
						scrollView.addView(message);
						
						layout.addView(scrollView);
						
						// =========================
						// BUTTON CONTAINER
						// =========================
						LinearLayout buttonLayout =
						new LinearLayout(
						HeroskinActivity.this
						);
						
						buttonLayout.setOrientation(
						LinearLayout.HORIZONTAL
						);
						
						buttonLayout.setGravity(
						Gravity.END
						);
						
						LinearLayout.LayoutParams buttonParams =
						new LinearLayout.LayoutParams(
						LinearLayout.LayoutParams.WRAP_CONTENT,
						(int) (40 * density)
						);
						
						buttonParams.topMargin =
						(int) (20 * density);
						
						buttonParams.leftMargin =
						(int) (10 * density);
						
						// =========================
						// RESET BUTTON
						// =========================
						Button resetButton =
						new Button(
						HeroskinActivity.this
						);
						
						resetButton.setText(
						"Reset Permission"
						);
						
						resetButton.setTextSize(14);
						
						resetButton.setTextColor(
						Color.WHITE
						);
						
						resetButton.setTypeface(
						Typeface.DEFAULT_BOLD
						);
						
						resetButton.setAllCaps(false);
						
						resetButton.setLayoutParams(
						buttonParams
						);
						
						GradientDrawable resetBg =
						new GradientDrawable();
						
						resetBg.setCornerRadius(
						16 * density
						);
						
						resetBg.setColor(
						Color.parseColor("#D50000")
						);
						
						resetBg.setStroke(
						3,
						Color.WHITE
						);
						
						resetButton.setBackground(
						resetBg
						);
						
						// =========================
						// OK BUTTON
						// =========================
						Button okButton =
						new Button(
						HeroskinActivity.this
						);
						
						okButton.setText("OK");
						
						okButton.setTextSize(14);
						
						okButton.setTextColor(
						Color.BLACK
						);
						
						okButton.setTypeface(
						Typeface.DEFAULT_BOLD
						);
						
						okButton.setAllCaps(false);
						
						okButton.setLayoutParams(
						buttonParams
						);
						
						GradientDrawable okBg =
						new GradientDrawable();
						
						okBg.setCornerRadius(
						16 * density
						);
						
						okBg.setColor(
						Color.parseColor("#FFFFFF")
						);
						
						okBg.setStroke(
						3,
						Color.WHITE
						);
						
						okButton.setBackground(okBg);
						
						// =========================
						// ANIMASI BUTTON
						// =========================
						View.OnTouchListener touchAnim =
						new View.OnTouchListener() {
							
							@Override
							public boolean onTouch(
							View btn,
							MotionEvent event
							) {
								
								switch (event.getAction()) {
									
									case MotionEvent.ACTION_DOWN:
									
									btn.animate()
									.scaleX(0.8f)
									.scaleY(0.8f)
									.setDuration(100)
									.start();
									
									break;
									
									case MotionEvent.ACTION_UP:
									
									case MotionEvent.ACTION_CANCEL:
									
									btn.animate()
									.scaleX(1f)
									.scaleY(1f)
									.setDuration(100)
									.start();
									
									break;
								}
								
								return false;
							}
						};
						
						resetButton.setOnTouchListener(
						touchAnim
						);
						
						okButton.setOnTouchListener(
						touchAnim
						);
						
						// =========================
						// ADD BUTTON
						// =========================
						buttonLayout.addView(
						resetButton
						);
						
						buttonLayout.addView(
						okButton
						);
						
						layout.addView(
						buttonLayout
						);
						
						// =========================
						// DIALOG
						// =========================
						AlertDialog.Builder builder =
						new AlertDialog.Builder(
						HeroskinActivity.this
						);
						
						builder.setView(layout);
						
						final AlertDialog dialog =
						builder.create();
						
						dialog.show();
						
						dialog.setCancelable(true);
						
						dialog.setCanceledOnTouchOutside(
						true
						);
						
						GradientDrawable bgDialog =
						new GradientDrawable();
						
						bgDialog.setCornerRadius(
						20 * density
						);
						
						bgDialog.setColor(
						Color.BLACK
						);
						
						bgDialog.setStroke(
						3,
						Color.WHITE
						);
						
						if (dialog.getWindow() != null) {
							
							dialog.getWindow()
							.setBackgroundDrawable(
							bgDialog
							);
						}
						
						// =========================
						// OK CLICK
						// =========================
						okButton.setOnClickListener(
						new View.OnClickListener() {
							
							@Override
							public void onClick(
							View v
							) {
								
								dialog.dismiss();
							}
						}
						);
						
						// =========================
						// RESET PERMISSION
						// =========================
						resetButton.setOnClickListener(new View.OnClickListener() {
							@Override
							public void onClick(View v) {
								dialog.dismiss();
								
								PermissionManager perm = new PermissionManager(HeroskinActivity.this);
								
								// Menghapus seluruh status izin lama termasuk cache iAdb
								sp.edit()
								.remove("DOWNLOAD_MODE")
								.remove("shizuku_selected")
								.remove("IADB_ALLOWED")
								.apply();
								
								AlertDialog.Builder dialog2 = new AlertDialog.Builder(HeroskinActivity.this);
								
								LinearLayout root = new LinearLayout(HeroskinActivity.this);
								root.setOrientation(LinearLayout.VERTICAL);
								root.setPadding(50, 50, 50, 50);
								root.setGravity(Gravity.CENTER_HORIZONTAL);
								
								// MEMBUAT BACKGROUND DIALOG HITAM DENGAN STROKE PUTIH
								GradientDrawable rootBg = new GradientDrawable();
								rootBg.setColor(0xFF000000); 
								rootBg.setCornerRadius(30);  
								rootBg.setStroke(3, Color.WHITE); 
								root.setBackground(rootBg);
								
								// JUDUL DIALOG RESET
								TextView title = new TextView(HeroskinActivity.this);
								title.setText("Select Permission");
								title.setTextSize(20);
								title.setTypeface(Typeface.DEFAULT_BOLD);
								title.setTextColor(Color.BLACK); 
								title.setPadding(30, 20, 30, 20);
								title.setGravity(Gravity.CENTER);
								
								GradientDrawable titleBg = new GradientDrawable();
								titleBg.setColor(0xFFFFFFFF);
								titleBg.setStroke(3, Color.BLACK);
								titleBg.setCornerRadius(20);
								title.setBackground(titleBg);
								
								// PENGECEKAN OTOMATIS SDK ANDROID
								String osVersion = android.os.Build.VERSION.RELEASE;
								int sdkVersion = android.os.Build.VERSION.SDK_INT;
								
								TextView deviceCheck = new TextView(HeroskinActivity.this);
								deviceCheck.setText("Android " + osVersion + " (SDK " + sdkVersion + ")");
								deviceCheck.setTextSize(14);
								deviceCheck.setTypeface(Typeface.DEFAULT_BOLD);
								deviceCheck.setTextColor(Color.YELLOW); 
								deviceCheck.setGravity(Gravity.CENTER);
								deviceCheck.setPadding(0, 20, 0, 5);
								
								// PESAN & PETUNJUK UTAMA
								TextView msg = new TextView(HeroskinActivity.this);
								msg.setText("Izin hanya diperlukan sekali saja\n\nAplikasi ini mungkin tidak berfungsi dengan baik tanpa izin yang diminta. Silakan pilih salah satu dari opsi di bawah ini untuk memberikan izin");
								msg.setTextColor(Color.WHITE); 
								msg.setTextSize(14);
								msg.setGravity(Gravity.CENTER);
								msg.setPadding(20, 10, 20, 20);
								
								// TOMBOL-TOMBOL OPSI DIALOG RESET
								Button defaultBtn = new Button(HeroskinActivity.this);
								Button shizukuBtn = new Button(HeroskinActivity.this);
								Button iadbBtn = new Button(HeroskinActivity.this);
								Button tutorialBtn = new Button(HeroskinActivity.this);
								Button laterBtn = new Button(HeroskinActivity.this);
								
								defaultBtn.setText("Default");
								shizukuBtn.setText("Shizuku");
								iadbBtn.setText("iAdb (Coming Soon)"); 
								tutorialBtn.setText("Tutorial");
								laterBtn.setText("Later");
								
								Button[] buttons = {defaultBtn, shizukuBtn, iadbBtn, tutorialBtn, laterBtn};
								
								LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
								LinearLayout.LayoutParams.MATCH_PARENT,
								LinearLayout.LayoutParams.WRAP_CONTENT
								);
								p.setMargins(0, 15, 0, 15);
								
								// PROSES STYLING & ANIMASI TOMBOL RESET
								for (Button b : buttons) {
									GradientDrawable bg = new GradientDrawable();
									bg.setColor(0xFFFFFFFF);
									bg.setStroke(3, Color.BLACK);
									bg.setCornerRadius(18);
									
									b.setLayoutParams(p);
									b.setBackground(bg);
									b.setBackgroundTintList(null);
									b.setStateListAnimator(null);
									b.setTextColor(Color.BLACK);
									b.setAllCaps(false);
									b.setTypeface(Typeface.DEFAULT_BOLD);
									b.setPadding(20, 20, 20, 20);
									
									b.setOnTouchListener((v1, event) -> {
										switch (event.getAction()) {
											case MotionEvent.ACTION_DOWN:
											v1.animate().scaleX(0.90f).scaleY(0.90f).setDuration(100).start();
											break;
											case MotionEvent.ACTION_UP:
											case MotionEvent.ACTION_CANCEL:
											v1.animate().scaleX(1f).scaleY(1f).setDuration(100).start();
											break;
										}
										return false;
									});
								}
								
								iadbBtn.setAlpha(0.6f); 
								
								// FOOTER TEXTVIEW DENGAN LINK PRIVACY POLICY
								TextView privacyText = new TextView(HeroskinActivity.this);
								privacyText.setGravity(Gravity.CENTER);
								privacyText.setPadding(20, 30, 20, 10);
								privacyText.setTextSize(13);
								privacyText.setTextColor(Color.WHITE); 
								
								String fullText = "Dengan memilih salah satu metode izin di atas, Anda menyetujui Kebijakan Privasi kami.";
								android.text.SpannableString ss = new android.text.SpannableString(fullText);
								
								android.text.style.ClickableSpan clickableSpan = new android.text.style.ClickableSpan() {
									@Override
									public void onClick(View textView) {
										try {
											Intent intentPrivacy = new Intent(Intent.ACTION_VIEW, Uri.parse("https://phoenixtoolsskin.blogspot.com/p/phoenix-tools-skin.html"));
											startActivity(intentPrivacy);
										} catch (Exception e) {
											Toast.makeText(HeroskinActivity.this, "Gagal membuka Kebijakan Privasi", Toast.LENGTH_SHORT).show();
										}
									}
									
									@Override
									public void updateDrawState(android.text.TextPaint ds) {
										ds.setColor(Color.CYAN);
										ds.setUnderlineText(true);
										ds.setFakeBoldText(false);
									}
								};
								
								String keyword = "Kebijakan Privasi";
								
								int start = fullText.indexOf(keyword);
								int end = start + keyword.length();
								
								ss.setSpan(
								clickableSpan,
								start,
								end,
								Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
								);
								
								privacyText.setText(ss);
								privacyText.setMovementMethod(android.text.method.LinkMovementMethod.getInstance());
								
								// LAYOUT SUSUNAN DIALOG KEDUA
								LinearLayout content = new LinearLayout(HeroskinActivity.this);
								content.setOrientation(LinearLayout.VERTICAL);
								
								content.addView(title);
								content.addView(deviceCheck); 
								content.addView(msg);         
								content.addView(defaultBtn);
								content.addView(shizukuBtn);
								content.addView(iadbBtn);
								content.addView(tutorialBtn);
								content.addView(laterBtn);
								content.addView(privacyText); 
								
								root.addView(content);
								dialog2.setView(root);
								
								final AlertDialog d2 = dialog2.create();
								
								if (d2.getWindow() != null) {
									d2.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
								}
								
								d2.show();
								
								// EVENT KLIK TOMBOL DIALOG RESET
								defaultBtn.setOnClickListener(new View.OnClickListener() {
									@Override
									public void onClick(View v) {
										sp.edit().putString("DOWNLOAD_MODE", "DEFAULT").apply();
										d2.dismiss();
										perm.RequestDataPermission();
									}
								});
								
								shizukuBtn.setOnClickListener(new View.OnClickListener() {
									@Override
									public void onClick(View v) {
										sp.edit().putString("DOWNLOAD_MODE", "SHIZUKU").putBoolean("shizuku_selected", false).apply();
										d2.dismiss();
										
										if (fyy == null || !fyy.isShizukuInstalled()) {
											Toast.makeText(HeroskinActivity.this, "Shizuku belum terinstall / siap", Toast.LENGTH_SHORT).show();
											return;
										}
										fyy.requestPermission();
										Toast.makeText(HeroskinActivity.this, "Shizuku Mode✅Klik Allow jika belum", Toast.LENGTH_SHORT).show();
									}
								});
								
								iadbBtn.setOnClickListener(new View.OnClickListener() {
									@Override
									public void onClick(View v) {
										Toast.makeText(HeroskinActivity.this, "Fitur iAdb segera hadir di pembaruan mendatang! 🚀", Toast.LENGTH_SHORT).show();
									}
								});
								
								tutorialBtn.setOnClickListener(new View.OnClickListener() {
									@Override
									public void onClick(View v) {
										try {
											startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://youtube.com/playlist?list=PL3fU1kworLKMQxcorEzMpShCCAWMFI17_&si=GrABJKsM2hYXh5bF")));
										} catch (Exception e) {
											Toast.makeText(HeroskinActivity.this, "Gagal membuka tautan tutorial", Toast.LENGTH_SHORT).show();
										}
									}
								});
								
								laterBtn.setOnClickListener(new View.OnClickListener() {
									@Override
									public void onClick(View v) {
										d2.dismiss();
									}
								});
							}
						});
						
					}
				})
				.start();
			}
		});
		
		perm = new PermissionManager(this);
		try {
			fyy = new ShizukuMaster(getApplicationContext());
		} catch (Exception e) {
			e.printStackTrace();
		}
		BroadcastReceiver onComplete = new BroadcastReceiver() {
			@Override
			public void onReceive(Context context, Intent intent) {
				
				long id = intent.getLongExtra(
				DownloadManager.EXTRA_DOWNLOAD_ID,
				-1
				);
				
				if (id != downloadId) return;
				
				Toast.makeText(
				getApplicationContext(),
				"Download completed",
				Toast.LENGTH_SHORT
				).show();
			}
		};
		
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
			registerReceiver(onComplete,
			new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE),
			Context.RECEIVER_NOT_EXPORTED
			);
		} else {
			registerReceiver(onComplete,
			new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE));
		}
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		if (perm != null) {
			perm.onActivityResult(
			_requestCode,
			_resultCode,
			_data
			);
		}
		
		// TRIK MUTLAK: Deteksi pembatalan folder SAF langsung di activity utama
		if (_requestCode == 1001) { // 1001 adalah NEW_FOLDER_REQUEST_CODE dari PermissionManager Anda
			if (_resultCode != Activity.RESULT_OK || _data == null || _data.getData() == null) {
				
				// Kosongkan DOWNLOAD_MODE di file sp utama Sketchware Anda secara paksa!
				sp.edit().putString("DOWNLOAD_MODE", "").apply();
				
				Toast.makeText(HeroskinActivity.this,
				"Izin dibatalkan, silakan pilih mode kembali",
				Toast.LENGTH_SHORT).show();
			}
		}
		
		// INTEGRASI SWITCH CASE UNTUK HANDLER BERBAGAI REQUEST CODE
		switch (_requestCode) {
			// Bagian iADB sengaja dikosongkan dari switch case ini karena
			// library iAdb Anda memproses callback via OnRequestPermissionResultListener internal.
			// Anda bisa menambahkan request code library lain di bawah sini jika dibutuhkan kelak.
			default:
			break;
		}
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	
	@Override
	public void onResume() {
		super.onResume();
		final SharedPreferences prefs =
		getSharedPreferences("app_prefs", MODE_PRIVATE);
		
		long now = System.currentTimeMillis();
		long lastShown = prefs.getLong("lastAlertTime", 0);
		
		// Cooldown 10 detik
		if (now - lastShown < 10_000) {
			return;
		}
		
		// Tunda lebih lama supaya iklan tidak terganggu
		new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
			@Override
			public void run() {
				
				if (isFinishing() || isDestroyed()) return;
				
				// 🔒 Cek ringan & aman (urutan penting)
				boolean blocked = false;
				
				if (_isBlockedDNS()) {
					blocked = true;
				} else if (_isVPNEnabled()) {
					blocked = true;
				}
				// ❌ _checkAdBlock() sengaja DIHILANGKAN
				// karena berat & sering bikin delay
				
				if (blocked) {
					// ✅ Dialog muncul saat UI sudah stabil
					_showBlockDialog();
					
					prefs.edit()
					.putLong("lastAlertTime", System.currentTimeMillis())
					.apply();
				}
			}
		}, 3000);
	}
	
	@Override
	public void onStart() {
		super.onStart();
		if (fyy != null) {
			// Handler ini bertugas menghangatkan koneksi Binder sejak awal aplikasi dibuka
			final Handler handler = new Handler();
			handler.postDelayed(new Runnable() {
				@Override
				public void run() {
					
					if (fyy.isShizukuAvailable()) {
						
						// Sinkronisasikan status izin asli secara otomatis ke SharedPreferences
						try {
							boolean allowed = fyy.hasPermission();
							sp.edit().putBoolean("SHIZUKU_ALLOWED", allowed).commit();
						} catch (Exception ignored) {}
						
						// Bagian pemulihan dokumen SAF Anda (hanya jalan jika shizuku_selected true)
						if (sp.getBoolean("shizuku_selected", false)) {
							String savedUri = sp.getString("FOLDER_URI", null);
							if (savedUri != null) {
								final Uri muri = Uri.parse(savedUri);
								final int takeFlags = Intent.FLAG_GRANT_READ_URI_PERMISSION
								| Intent.FLAG_GRANT_WRITE_URI_PERMISSION;
								try {
									getContentResolver().takePersistableUriPermission(muri, takeFlags);
									sp.edit().putBoolean("shizuku_selected", false).commit();
									SketchwareUtil.showMessage(getApplicationContext(), "Shizuku permission restored✅");
								} catch (Exception e) {
									e.printStackTrace();
								}
							}
						}
						
					} else {
						// Jika Binder belum terikat sempurna di latar belakang, lakukan retry setiap 500ms
						handler.postDelayed(this, 500);
					}
				}
			}, 500); // Delay pertama 500ms
		}
		
	}
	public void _setCornerRadius(final View _view, final double _value, final String _color) {
		android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
		gd.setColor(Color.parseColor(_color));
		gd.setCornerRadius((int)_value);
		_view.setBackground(gd);
		_view.setElevation(5);
	}
	
	
	public void _Anehgaminginejvtor(final ImageView _img, final String _file, final String _url) {
		Glide.with(getContext(this)).load(_url).thumbnail(Glide.with(getContext(this)).load(getContext(this).getResources().getIdentifier(_file, "drawable", getContext(this).getPackageName()))).fitCenter().into(_img);
	}
	public Context getContext(Context c) {
		return c;
	}
	public Context getContext(Fragment f) {
		return f.getActivity();
	}
	public Context getContext(DialogFragment df) {
		return df.getActivity();
	}
	{
	}
	
	
	public void _AnehGamingOfficial(final ArrayList<HashMap<String, Object>> _listmap, final String _aneh) {
		Comparator list_sorter = new Comparator<HashMap<String, Object>>(){
			@Override
			public int compare(HashMap<String, Object> map2, HashMap<String, Object> map1){
				
				try {
					Double num1 = Double.parseDouble(map1.get(_aneh).toString());
					Double num2 = Double.parseDouble(map2.get(_aneh).toString());
					return Double.compare(num2, num1);
				} catch (NumberFormatException e){
					return map2.get(_aneh).toString().compareTo(map1.get(_aneh).toString());
				}
				
			}
		};
		
		Collections.sort(_listmap, list_sorter);
	}
	
	
	public void _setProperties(final View _view, final double _radius, final double _stroke, final String _strokeColor, final String _bgColor) {
		_view.setBackground(new android.graphics.drawable.GradientDrawable() {
			
			public android.graphics.drawable.GradientDrawable getIns(int a, int b, int c, int d) {
				
				this.setCornerRadius(a);
				this.setStroke(b, c);
				this.setColor(d);
				return this;
			}
		}
		.getIns((int)_radius, (int)_stroke, Color.parseColor(_strokeColor), Color.parseColor(_bgColor)));
	}
	
	
	public void _GradientDrawable(final View _view, final double _radius, final double _stroke, final double _shadow, final String _color, final String _borderColor, final boolean _ripple, final boolean _clickAnim, final double _animDuration) {
		if (_ripple) {
			android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
			gd.setColor(Color.parseColor(_color));
			gd.setCornerRadius((int)_radius);
			gd.setStroke((int)_stroke,Color.parseColor(_borderColor));
			if (Build.VERSION.SDK_INT >= 21){
				_view.setElevation((int)_shadow);}
			android.content.res.ColorStateList clrb = new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{Color.parseColor("#9e9e9e")});
			android.graphics.drawable.RippleDrawable ripdrb = new android.graphics.drawable.RippleDrawable(clrb , gd, null);
			_view.setClickable(true);
			_view.setBackground(ripdrb);
		} else {
			android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
			gd.setColor(Color.parseColor(_color));
			gd.setCornerRadius((int)_radius);
			gd.setStroke((int)_stroke,Color.parseColor(_borderColor));
			_view.setBackground(gd);
			if (Build.VERSION.SDK_INT >= 21){
				_view.setElevation((int)_shadow);}
		}
		if (_clickAnim) {
			_view.setOnTouchListener(new View.OnTouchListener() {
				@Override
				public boolean onTouch(View v, MotionEvent event) {
					switch (event.getAction()){
						case MotionEvent.ACTION_DOWN:{
							ObjectAnimator scaleX = new ObjectAnimator();
							scaleX.setTarget(_view);
							scaleX.setPropertyName("scaleX");
							scaleX.setFloatValues(0.9f);
							scaleX.setDuration((int)_animDuration);
							scaleX.start();
							
							ObjectAnimator scaleY = new ObjectAnimator();
							scaleY.setTarget(_view);
							scaleY.setPropertyName("scaleY");
							scaleY.setFloatValues(0.9f);
							scaleY.setDuration((int)_animDuration);
							scaleY.start();
							break;
						}
						case MotionEvent.ACTION_UP:{
							
							ObjectAnimator scaleX = new ObjectAnimator();
							scaleX.setTarget(_view);
							scaleX.setPropertyName("scaleX");
							scaleX.setFloatValues((float)1);
							scaleX.setDuration((int)_animDuration);
							scaleX.start();
							
							ObjectAnimator scaleY = new ObjectAnimator();
							scaleY.setTarget(_view);
							scaleY.setPropertyName("scaleY");
							scaleY.setFloatValues((float)1);
							scaleY.setDuration((int)_animDuration);
							scaleY.start();
							
							break;
						}
					}
					return false;
				}
			});
		}
		_view.setClipToOutline(true);
	}
	
	
	public boolean _checkAdBlock() {
		if (_isVPNEnabled() || _isBlockedDNS()) {
			return true; // hanya kembalikan nilai
		}
		return false;
	}
	
	
	public boolean _isVPNEnabled() {
		try {
			// ================================
			// 1) VPN RESMI (PALING AMAN)
			// ================================
			ConnectivityManager cm =
			(ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
			
			if (cm != null) {
				Network network = cm.getActiveNetwork();
				NetworkCapabilities caps = cm.getNetworkCapabilities(network);
				
				if (caps != null &&
				caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) {
					return true;
				}
			}
			
			// ================================
			// 2) INTERFACE CHECK (BACKUP)
			// ================================
			for (NetworkInterface ni :
			java.util.Collections.list(NetworkInterface.getNetworkInterfaces())) {
				
				if (!ni.isUp() || ni.isLoopback()) continue;
				
				String name = ni.getName().toLowerCase(); // pakai getName(), lebih aman
				
				if (name.contains("tun")
				|| name.contains("wg")
				|| name.contains("ppp")) {
					
					return true;
				}
			}
			
			return false;
			
		} catch (Exception e) {
			return false;
		}
		
	}
	
	
	public boolean _isBlockedDNS() {
		try {
			if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
				String mode = Settings.Global.getString(
				getContentResolver(),
				"private_dns_mode"
				);
				
				String host = Settings.Global.getString(
				getContentResolver(),
				"private_dns_specifier"
				);
				
				if ("hostname".equals(mode) && host != null) {
					host = host.toLowerCase();
					return host.contains("adguard")
					|| host.contains("nextdns")
					|| host.contains("blokada");
				}
			}
		} catch (Throwable ignored) {}
		return false;
	}
	
	
	public void _showBlockDialog() {
		if (isFinishing() || isDestroyed()) return;
		
		androidx.appcompat.app.AlertDialog.Builder builder =
		new androidx.appcompat.app.AlertDialog.Builder(this);
		
		builder.setTitle("Koneksi Tidak Stabil • Unstable Connection");
		
		builder.setMessage(
		"Beberapa pengaturan jaringan atau DNS dapat memengaruhi " +
		"kestabilan koneksi aplikasi.\n\n" +
		"Jika Anda mengalami kendala, silakan nonaktifkan sementara " +
		"pengaturan tersebut lalu coba kembali.\n\n" +
		"Some network or DNS configurations may affect the app’s " +
		"connection stability.\n\n" +
		"If you experience issues, please temporarily disable such " +
		"settings and try again."
		);
		
		// ✅ Biarkan user bisa dismiss
		builder.setCancelable(true);
		
		// 🔁 COBA LAGI / RETRY
		builder.setPositiveButton("Coba Lagi / Retry",
		new android.content.DialogInterface.OnClickListener() {
			@Override
			public void onClick(android.content.DialogInterface dialog, int which) {
				
				dialog.dismiss();
				
				// Cek ulang DNS secara ringan
				if (!_isBlockedDNS()) {
					// lanjutkan aplikasi
					// contoh: loadData(); atau refresh halaman
				}
			}
		});
		
		// ⬅️ KEMBALI / BACK (lebih aman daripada force close)
		builder.setNegativeButton("Kembali / Back",
		new android.content.DialogInterface.OnClickListener() {
			@Override
			public void onClick(android.content.DialogInterface dialog, int which) {
				dialog.dismiss();
			}
		});
		
		builder.show();
		
	}
	
	
	public void _initShizukuOnCreate() {
		try {
			fyy = new ShizukuMaster(getApplicationContext());
		} catch (Exception e) {
		}
	}
	
	
	public void _CheckShizukuOnStart() {
		if (fyy == null) return;
		
		try {
			
			boolean installed = fyy.isShizukuInstalled();
			boolean available = fyy.isShizukuAvailable();
			boolean allowed = false;
			
			if (installed && available) {
				allowed = fyy.hasPermission();
			}
			
			sp.edit()
			.putBoolean("SHIZUKU_ALLOWED", allowed)
			.apply();
			
		} catch (Exception e) {
			
			sp.edit()
			.putBoolean("SHIZUKU_ALLOWED", false)
			.apply();
			
		}
	}
	
	
	public void _showModeDialog() {
		AlertDialog.Builder dialog = new AlertDialog.Builder(HeroskinActivity.this);
		
		LinearLayout root = new LinearLayout(HeroskinActivity.this);
		root.setOrientation(LinearLayout.VERTICAL);
		root.setPadding(50, 50, 50, 50);
		root.setGravity(Gravity.CENTER_HORIZONTAL);
		
		// ================= MEMBUAT BACKGROUND DIALOG HITAM DENGAN SUDUT MELENGKUNG =================
		GradientDrawable rootBg = new GradientDrawable();
		rootBg.setColor(0xFF000000); // Warna Hitam Pekat
		rootBg.setCornerRadius(30);
		rootBg.setStroke(3, Color.WHITE);  // Membuat sudut dialog melengkung halus
		root.setBackground(rootBg);
		
		// ================= 1. JUDUL DIALOG =================
		TextView title = new TextView(HeroskinActivity.this);
		title.setText("Permission Required");
		title.setTextSize(20);
		title.setTypeface(Typeface.DEFAULT_BOLD);
		title.setTextColor(Color.BLACK); // Dipastikan Putih
		title.setPadding(30, 20, 30, 20);
		title.setGravity(Gravity.CENTER);
		
		GradientDrawable titleBg = new GradientDrawable();
		titleBg.setColor(0xFFFFFFFF);
		titleBg.setStroke(3, Color.BLACK);
		titleBg.setCornerRadius(20);
		title.setBackground(titleBg);
		
		// ================= 2. PENGECEKAN OTOMATIS SDK ANDROID =================
		String osVersion = android.os.Build.VERSION.RELEASE;
		int sdkVersion = android.os.Build.VERSION.SDK_INT;
		
		TextView deviceCheck = new TextView(HeroskinActivity.this);
		deviceCheck.setText("Android " + osVersion + " (SDK " + sdkVersion + ")");
		deviceCheck.setTextSize(14);
		deviceCheck.setTypeface(Typeface.DEFAULT_BOLD);
		deviceCheck.setTextColor(Color.YELLOW); // Warna kuning agar kontras di atas background hitam
		deviceCheck.setGravity(Gravity.CENTER);
		deviceCheck.setPadding(0, 20, 0, 5);
		
		// ================= 3. PESAN & PETUNJUK UTAMA =================
		TextView msg = new TextView(HeroskinActivity.this);
		msg.setText("Izin hanya diperlukan sekali saja\n\nAplikasi ini mungkin tidak berfungsi dengan baik tanpa izin yang diminta. Silakan pilih salah satu dari opsi di bawah ini untuk memberikan izin");
		msg.setTextColor(Color.WHITE); // Dipastikan Putih
		msg.setTextSize(14);
		msg.setGravity(Gravity.CENTER);
		msg.setPadding(20, 10, 20, 20);
		
		// ================= 4. TOMBOL-TOMBOL OPSI =================
		Button def = new Button(HeroskinActivity.this);
		Button shizuku = new Button(HeroskinActivity.this);
		Button iadb = new Button(HeroskinActivity.this); 
		Button tutorial = new Button(HeroskinActivity.this);
		Button later = new Button(HeroskinActivity.this);
		
		def.setText("Default");
		shizuku.setText("Shizuku");
		iadb.setText("iAdb (Coming Soon)"); 
		tutorial.setText("Tutorial");
		later.setText("Later");
		
		Button[] btns = {def, shizuku, iadb, tutorial, later};
		
		LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
		LinearLayout.LayoutParams.MATCH_PARENT,
		LinearLayout.LayoutParams.WRAP_CONTENT
		);
		params.setMargins(0, 15, 0, 15);
		
		// PROSES STYLING & PENAMBAHAN ANIMASI GERAK OTOMATIS
		for (Button b : btns) {
			GradientDrawable bg = new GradientDrawable();
			bg.setColor(0xFFFFFFFF);
			bg.setStroke(3, Color.BLACK);
			bg.setCornerRadius(18);
			
			b.setLayoutParams(params);
			b.setBackground(bg);
			b.setBackgroundTintList(null);
			b.setStateListAnimator(null);
			b.setTextColor(Color.BLACK); // Text di dalam button tetap Putih
			b.setAllCaps(false);
			b.setTypeface(Typeface.DEFAULT_BOLD);
			b.setPadding(20, 20, 20, 20);
			
			b.setOnTouchListener((v, event) -> {
				switch (event.getAction()) {
					case MotionEvent.ACTION_DOWN:
					v.animate().scaleX(0.90f).scaleY(0.90f).setDuration(100).start();
					break;
					case MotionEvent.ACTION_UP:
					case MotionEvent.ACTION_CANCEL:
					v.animate().scaleX(1f).scaleY(1f).setDuration(100).start();
					break;
				}
				return false;
			});
		}
		
		// Mengurangi kepekatan tombol iADB karena statusnya Coming Soon
		iadb.setAlpha(0.6f); 
		
		// ================= 5. FOOTER TEXTVIEW DENGAN LINK PRIVACY POLICY =================
		TextView privacyText = new TextView(HeroskinActivity.this);
		privacyText.setGravity(Gravity.CENTER);
		privacyText.setPadding(20, 30, 20, 10);
		privacyText.setTextSize(13);
		privacyText.setTextColor(Color.WHITE); // Teks utama diubah menjadi Putih
		
		String fullText = "Dengan memilih salah satu metode izin di atas, Anda menyetujui Kebijakan Privasi kami.";
		android.text.SpannableString ss = new android.text.SpannableString(fullText);
		
		android.text.style.ClickableSpan clickableSpan = new android.text.style.ClickableSpan() {
			@Override
			public void onClick(View textView) {
				try {
					Intent intentPrivacy = new Intent(Intent.ACTION_VIEW, Uri.parse("https://phoenixtoolsskin.blogspot.com/p/phoenix-tools-skin.html"));
					startActivity(intentPrivacy);
				} catch (Exception e) {
					Toast.makeText(HeroskinActivity.this, "Gagal membuka Kebijakan Privasi", Toast.LENGTH_SHORT).show();
				}
			}
			
			@Override
			public void updateDrawState(android.text.TextPaint ds) {
				ds.setColor(Color.CYAN);
				ds.setUnderlineText(true);
				ds.setFakeBoldText(false);
			}
		};
		
		// Target kata "Kebijakan Privasi" (indeks 41 sampai 58)
		String keyword = "Kebijakan Privasi";
		
		int start = fullText.indexOf(keyword);
		int end = start + keyword.length();
		
		ss.setSpan(
		clickableSpan,
		start,
		end,
		Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
		);
		
		privacyText.setText(ss);
		privacyText.setMovementMethod(android.text.method.LinkMovementMethod.getInstance());
		
		
		// ================= LAYOUT SUSUNAN DIALOG =================
		LinearLayout content = new LinearLayout(HeroskinActivity.this);
		content.setOrientation(LinearLayout.VERTICAL);
		
		content.addView(title);
		content.addView(deviceCheck); 
		content.addView(msg);         
		content.addView(def);
		content.addView(shizuku);
		content.addView(iadb); 
		content.addView(tutorial);
		content.addView(later);
		content.addView(privacyText); 
		
		root.addView(content);
		dialog.setView(root);
		
		AlertDialog d = dialog.create();
		
		// 🔥 KUNCI UTAMA: Menghilangkan paksa background abu-abu/hitam bawaan Android AlertDialog
		if (d.getWindow() != null) {
			d.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
		}
		
		def.setOnClickListener(v -> {
			sp.edit().putString("DOWNLOAD_MODE", "DEFAULT").apply();
			d.dismiss();
			PermissionManager pm = new PermissionManager(HeroskinActivity.this);
			if (!pm.IsPermissionGranted()) {
				pm.RequestDataPermission();
			}
		});
		
		shizuku.setOnClickListener(v -> {
			sp.edit().putString("DOWNLOAD_MODE", "SHIZUKU").apply();
			d.dismiss();
			
			if (fyy != null && fyy.isShizukuInstalled()) {
				boolean hasPerm = false;
				try { 
					hasPerm = fyy.hasPermission(); 
				} catch (Exception e) { 
					hasPerm = false; 
				}
				
				if (!hasPerm) {
					fyy.requestPermission();
					Toast.makeText(HeroskinActivity.this,
					"Klik 'Allow' lalu klik lagi untuk mendownload",
					Toast.LENGTH_SHORT).show();
				}
			} else {
				Toast.makeText(HeroskinActivity.this, 
				"Shizuku belum terinstall / belum siap", 
				Toast.LENGTH_SHORT).show();
			}
		});
		
		// ================= iADB =================
		iadb.setOnClickListener(v -> {
			// Reset mode agar user tidak terjebak di mode iADB yang belum siap
			sp.edit().putString("DOWNLOAD_MODE", "").apply();
			d.dismiss();
			
			// Toast pemberitahuan murni ke pengguna
			Toast.makeText(HeroskinActivity.this, "Fitur iAdb segera hadir di pembaruan mendatang! 🚀", Toast.LENGTH_LONG).show();
		});
		
		
		// ================= TUTORIAL =================
		tutorial.setOnClickListener(v -> {
			try {
				Intent intentUtube = new Intent(Intent.ACTION_VIEW, Uri.parse("https://youtube.com/playlist?list=PL3fU1kworLKMQxcorEzMpShCCAWMFI17_&si=GrABJKsM2hYXh5bF"));
				startActivity(intentUtube);
			} catch (Exception e) {
				Toast.makeText(HeroskinActivity.this, "Gagal membuka tautan tutorial", Toast.LENGTH_SHORT).show();
			}
		});
		
		// ================= LATER =================
		later.setOnClickListener(v -> {
			sp.edit().putString("DOWNLOAD_MODE", "").apply();
			d.dismiss();
		});
		
		// ================= ANTISIPASI BACK / KLIK LUAR DIALOG =================
		d.setOnCancelListener(dialogInterface -> {
			sp.edit().putString("DOWNLOAD_MODE", "").apply();
		});
		
		d.show();
	}
	
	public class Recyclerview1Adapter extends RecyclerView.Adapter<Recyclerview1Adapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Recyclerview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getLayoutInflater();
			View _v = _inflater.inflate(R.layout.heroskinn, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			final TextView textview1 = _view.findViewById(R.id.textview1);
			
			final int pos = (int)_position; // 🟢 RUMUS NORMAL KEMBALI PULANG!
			
			if (pos >= 0) {
				if (linear1 != null && textview1 != null && imageview1 != null) {
					
					View headerView_kustom = (View) recyclerview1.getTag(R.id.imageview2);
					
					// Cek status keaktifan hero berdasarkan data ListMap detail hero
					boolean apakahHeroAdaDiGitHub = false;
					String namaHeroTerpilih_onBind = sp.getString("her", "");
					if (listDetailHero != null && !listDetailHero.isEmpty() && !namaHeroTerpilih_onBind.isEmpty()) {
						for (int i = 0; i < listDetailHero.size(); i++) {
							java.util.HashMap<String, Object> tempHero = listDetailHero.get(i);
							if (tempHero.containsKey("her") && String.valueOf(tempHero.get("her")).equalsIgnoreCase(namaHeroTerpilih_onBind)) {
								apakahHeroAdaDiGitHub = true; 
								break;
							}
						}
					}
					
					// ========================================================
					// 🔥 STEP 1: LOGIKA MULTI-VIEW TYPE LANTAI ATAS (DETAIL HERO)
					// ========================================================
					if (pos == 0 && apakahHeroAdaDiGitHub) {
						
						if (headerView_kustom != null) {
							headerView_kustom.setVisibility(View.VISIBLE);
							
							if (_view instanceof android.widget.LinearLayout) {
								android.widget.LinearLayout mainRowLayout = (android.widget.LinearLayout) _view;
								mainRowLayout.setOrientation(android.widget.LinearLayout.VERTICAL);
								
								linear1.setVisibility(View.GONE);
								
								if (headerView_kustom.getParent() != null && headerView_kustom.getParent() != mainRowLayout) {
									((android.view.ViewGroup)headerView_kustom.getParent()).removeView(headerView_kustom);
								}
								
								boolean sudahMenempel = false;
								for (int i = 0; i < mainRowLayout.getChildCount(); i++) {
									if (mainRowLayout.getChildAt(i) == headerView_kustom) {
										sudahMenempel = true;
										break;
									}
								}
								if (!sudahMenempel) {
									mainRowLayout.addView(headerView_kustom, 0);
								}
							}
							
							// 🚀 PROSES TEMBAK DATA DIJALANKAN DI ONBIND
							try {
								java.util.HashMap<String, Object> finalHeroData = null;
								for (int i = 0; i < listDetailHero.size(); i++) {
									java.util.HashMap<String, Object> tempHero = listDetailHero.get(i);
									if (tempHero.containsKey("her") && String.valueOf(tempHero.get("her")).equalsIgnoreCase(namaHeroTerpilih_onBind)) {
										finalHeroData = tempHero;
										break;
									}
								}
								
								if (finalHeroData != null) {
									
									final LinearLayout layoutHeroStats_kustom = headerView_kustom.findViewById(R.id.layoutHeroStats);
									LinearLayout layoutSkillTitle_kustom = headerView_kustom.findViewById(R.id.layoutSkillTitle);
									LinearLayout layoutSkillDesc_kustom = headerView_kustom.findViewById(R.id.layoutSkillDesc);
									LinearLayout layoutBestBuild_kustom = headerView_kustom.findViewById(R.id.layoutBestBuild);
									LinearLayout layoutSkillIconContainer = headerView_kustom.findViewById(R.id.layoutSkillIcon);
									
									TextView heroRole_kustom = headerView_kustom.findViewById(R.id.heroRole);
									TextView textSkillTitle_kustom = headerView_kustom.findViewById(R.id.textSkillTitle);
									TextView textSkillDesc_kustom = headerView_kustom.findViewById(R.id.textSkillDesc);
									TextView textBestBuild_kustom = headerView_kustom.findViewById(R.id.textBestBuild);
									
									ImageView imageview2_kustom = headerView_kustom.findViewById(R.id.imageview2);
									ImageView imgSkillPasif_kustom = headerView_kustom.findViewById(R.id.imgSkillPasif); 
									ImageView imgSkill1_kustom = headerView_kustom.findViewById(R.id.imgSkill1);
									ImageView imgSkill2_kustom = headerView_kustom.findViewById(R.id.imgSkill2);
									ImageView imgSkillUlt_kustom = headerView_kustom.findViewById(R.id.imgSkillUlt);
									
									ProgressBar progressDurability_kustom = headerView_kustom.findViewById(R.id.progressDurability);
									ProgressBar progressOffense_kustom = headerView_kustom.findViewById(R.id.progressOffense);
									ProgressBar progressControl_kustom = headerView_kustom.findViewById(R.id.progressControl);
									ProgressBar progressDifficulty_kustom = headerView_kustom.findViewById(R.id.progressDifficulty);
									
									final float density_kustom = _view.getContext().getResources().getDisplayMetrics().density;
									
									// Dekorasi Style Box Deskripsi
									android.graphics.drawable.GradientDrawable styleBox_kustom = new android.graphics.drawable.GradientDrawable();
									styleBox_kustom.setColor(Color.parseColor("#BD000000"));
									styleBox_kustom.setStroke((int)(1 * density_kustom), Color.WHITE);
									styleBox_kustom.setCornerRadius(10 * density_kustom);
									
									int paddingHorizontal = (int)(16 * density_kustom);
									int paddingVertical = (int)(12 * density_kustom);
									
									LinearLayout.LayoutParams boksParams = new LinearLayout.LayoutParams(
									LinearLayout.LayoutParams.MATCH_PARENT,
									LinearLayout.LayoutParams.WRAP_CONTENT
									);
									
									boksParams.setMargins(
									(int)(10 * density_kustom),
									(int)(6 * density_kustom),
									(int)(10 * density_kustom),
									(int)(6 * density_kustom)
									);
									
									if (layoutSkillTitle_kustom != null) {
										layoutSkillTitle_kustom.setBackground(styleBox_kustom);
										layoutSkillTitle_kustom.setPadding(
										paddingHorizontal,
										paddingVertical,
										paddingHorizontal,
										paddingVertical
										);
										layoutSkillTitle_kustom.setLayoutParams(boksParams);
										
										if (layoutSkillTitle_kustom instanceof android.widget.LinearLayout) {
											((android.widget.LinearLayout) layoutSkillTitle_kustom)
											.setGravity(android.view.Gravity.CENTER_VERTICAL);
										}
									}
									
									if (layoutSkillDesc_kustom != null) {
										layoutSkillDesc_kustom.setBackground(styleBox_kustom);
										layoutSkillDesc_kustom.setPadding(
										paddingHorizontal,
										paddingVertical,
										paddingHorizontal,
										paddingVertical
										);
										layoutSkillDesc_kustom.setLayoutParams(boksParams);
									}
									
									// Style Box Best Build
									android.graphics.drawable.GradientDrawable styleBuild_kustom = new android.graphics.drawable.GradientDrawable();
									styleBuild_kustom.setColor(Color.parseColor("#BD000000")); 
									styleBuild_kustom.setStroke((int)(1.5f * density_kustom), Color.WHITE);
									styleBuild_kustom.setCornerRadius(10 * density_kustom);
									
									if (layoutBestBuild_kustom != null) {
										layoutBestBuild_kustom.setBackground(styleBuild_kustom);
										layoutBestBuild_kustom.setLayoutParams(boksParams);
									}
									
									// Boks Ikon Skill
									if (layoutSkillIconContainer != null) {
										android.graphics.drawable.GradientDrawable styleContainerSkill = new android.graphics.drawable.GradientDrawable();
										styleContainerSkill.setColor(Color.parseColor("#BD000000"));
										styleContainerSkill.setStroke((int)(1.5f * density_kustom), Color.WHITE);
										styleContainerSkill.setCornerRadius(10 * density_kustom);
										layoutSkillIconContainer.setBackground(styleContainerSkill);
										layoutSkillIconContainer.setLayoutParams(boksParams);
									}
									
									// Isi Data Teks
									if (heroRole_kustom != null && finalHeroData.containsKey("roll")) {
										heroRole_kustom.setText(String.valueOf(finalHeroData.get("roll")));
									}
									
									if (textSkillTitle_kustom != null && finalHeroData.containsKey("skill_title")) {
										textSkillTitle_kustom.setText(String.valueOf(finalHeroData.get("skill_title")));
										textSkillTitle_kustom.setLineSpacing(2f, 1.1f); 
										textSkillTitle_kustom.setGravity(android.view.Gravity.CENTER_VERTICAL);
										textSkillTitle_kustom.setPadding(0, 0, 0, 0);
										textSkillTitle_kustom.setLayoutParams(
										new android.widget.LinearLayout.LayoutParams(
										android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
										android.widget.LinearLayout.LayoutParams.WRAP_CONTENT
										)
										);
									}
									
									if (textSkillDesc_kustom != null && finalHeroData.containsKey("skill_desc")) {
										textSkillDesc_kustom.setText(String.valueOf(finalHeroData.get("skill_desc")));
									}
									
									// 🚀 REKOMENDASI BUILD
									if (textBestBuild_kustom != null && finalHeroData.containsKey("best_build")) {
										String itemDariGitHub = String.valueOf(finalHeroData.get("best_build"));
										textBestBuild_kustom.setText("Rekomendasi Build : " + itemDariGitHub);
										textBestBuild_kustom.setLineSpacing(2f, 1.1f);
									}
									
									// ========================================================
									// 🔥 PREMIUM PROGRESS BAR
									// TANPA SHINE
									// FILL + BULATAN DI UJUNG PROGRESS
									// ========================================================
									try {
										
										final int durability = Math.max(0, Math.min(100,
										Integer.parseInt(String.valueOf(
										finalHeroData.get("stat_durability")
										))
										));
										
										final int offense = Math.max(0, Math.min(100,
										Integer.parseInt(String.valueOf(
										finalHeroData.get("stat_offense")
										))
										));
										
										final int control = Math.max(0, Math.min(100,
										Integer.parseInt(String.valueOf(
										finalHeroData.get("stat_control")
										))
										));
										
										final int difficulty = Math.max(0, Math.min(100,
										Integer.parseInt(String.valueOf(
										finalHeroData.get("stat_difficulty")
										))
										));
										
										// ====================================================
										// TEXT PERSENTASE
										// ====================================================
										TextView textDurabilityPercent =
										headerView_kustom.findViewById(R.id.textDurabilityPercent);
										
										TextView textOffensePercent =
										headerView_kustom.findViewById(R.id.textOffensePercent);
										
										TextView textControlPercent =
										headerView_kustom.findViewById(R.id.textControlPercent);
										
										TextView textDifficultyPercent =
										headerView_kustom.findViewById(R.id.textDifficultyPercent);
										
										if (textDurabilityPercent != null) {
											textDurabilityPercent.setText(
											"Ketahanan  " + durability + "%"
											);
										}
										
										if (textOffensePercent != null) {
											textOffensePercent.setText(
											"Serangan  " + offense + "%"
											);
										}
										
										if (textControlPercent != null) {
											textControlPercent.setText(
											"Efek Kontrol  " + control + "%"
											);
										}
										
										if (textDifficultyPercent != null) {
											textDifficultyPercent.setText(
											"Kesulitan  " + difficulty + "%"
											);
										}
										
										// ====================================================
										// 🔥 PREMIUM PROGRESS DRAWABLE
										// FILL + BULATAN DI UJUNG
										// ====================================================
										class PremiumProgressDrawable
										extends android.graphics.drawable.Drawable {
											
											private final android.graphics.Paint paint =
											new android.graphics.Paint(
											android.graphics.Paint.ANTI_ALIAS_FLAG
											);
											
											private int baseColor;
											private float progress = 0f;
											
											PremiumProgressDrawable(int color) {
												baseColor = color;
												paint.setDither(true);
											}
											
											public void setProgressValue(float value) {
												
												progress = Math.max(
												0f,
												Math.min(100f, value)
												);
												
												invalidateSelf();
											}
											
											@Override
											public void draw(android.graphics.Canvas canvas) {
												
												android.graphics.Rect bounds =
												getBounds();
												
												if (bounds.width() <= 0 ||
												bounds.height() <= 0) {
													return;
												}
												
												float width =
												bounds.width();
												
												float height =
												bounds.height();
												
												float radius =
												height / 2f;
												
												// ====================================================
												// 🔳 BACKGROUND / TRACK
												// GELAP SEMI-TRANSPARAN
												// ====================================================
												paint.setShader(null);
												
												paint.setStyle(
												android.graphics.Paint.Style.FILL
												);
												
												paint.setColor(
												android.graphics.Color.parseColor(
												"#66000000"
												)
												);
												
												android.graphics.RectF fullRect =
												new android.graphics.RectF(
												bounds.left,
												bounds.top,
												bounds.right,
												bounds.bottom
												);
												
												canvas.drawRoundRect(
												fullRect,
												radius,
												radius,
												paint
												);
												
												// ====================================================
												// HITUNG LEBAR FILL
												// ====================================================
												float fillWidth =
												width * (progress / 100f);
												
												if (fillWidth <= 0f) {
													return;
												}
												
												// ====================================================
												// 🔥 FILL SESUAI PERSENTASE
												// ====================================================
												android.graphics.RectF fillRect =
												new android.graphics.RectF(
												bounds.left,
												bounds.top,
												bounds.left + fillWidth,
												bounds.bottom
												);
												
												paint.setColor(baseColor);
												
												canvas.drawRoundRect(
												fillRect,
												radius,
												radius,
												paint
												);
												
												// ====================================================
												// 🔘 BULATAN DI UJUNG PROGRESS
												// ====================================================
												float circleRadius =
												Math.max(
												3f,
												height * 0.35f
												);
												
												float circleX =
												bounds.left + fillWidth;
												
												float circleY =
												bounds.top + (height / 2f);
												
												// ====================================================
												// BATASI AGAR BULATAN TIDAK KELUAR BAR
												// ====================================================
												circleX = Math.max(
												bounds.left + circleRadius,
												Math.min(
												bounds.right - circleRadius,
												circleX
												)
												);
												
												// ====================================================
												// ⚪ OUTLINE PUTIH
												// ====================================================
												paint.setShader(null);
												
												paint.setColor(
												android.graphics.Color.WHITE
												);
												
												canvas.drawCircle(
												circleX,
												circleY,
												circleRadius + 1.5f,
												paint
												);
												
												// ====================================================
												// 🔘 BULATAN WARNA UTAMA
												// ====================================================
												paint.setColor(baseColor);
												
												canvas.drawCircle(
												circleX,
												circleY,
												circleRadius,
												paint
												);
												
												// ====================================================
												// ⚪ TITIK PUTIH DI TENGAH
												// ====================================================
												paint.setColor(
												android.graphics.Color.WHITE
												);
												
												canvas.drawCircle(
												circleX,
												circleY,
												circleRadius * 0.28f,
												paint
												);
											}
											
											@Override
											public void setAlpha(int alpha) {
												paint.setAlpha(alpha);
											}
											
											@Override
											public void setColorFilter(
											android.graphics.ColorFilter colorFilter
											) {
												paint.setColorFilter(colorFilter);
											}
											
											@Override
											public int getOpacity() {
												return android.graphics.PixelFormat.TRANSLUCENT;
											}
										}
										
										// ========================================================
										// 🔥 SETUP PROGRESS BAR
										// ========================================================
										java.util.function.BiConsumer<ProgressBar, Integer> setupProgress =
										(progressBar, targetValue) -> {
											
											if (progressBar == null) {
												return;
											}
											
											// ====================================================
											// 🎨 WARNA MASING-MASING
											// ====================================================
											final int progressColor;
											
											if (progressBar == progressDurability_kustom) {
												
												// 🟢 KETAHAHAN
												progressColor =
												android.graphics.Color.parseColor(
												"#00E676"
												);
												
											} else if (progressBar == progressOffense_kustom) {
												
												// 🔴 SERANGAN
												progressColor =
												android.graphics.Color.parseColor(
												"#FF1744"
												);
												
											} else if (progressBar == progressControl_kustom) {
												
												// 🔵 EFEK KONTROL
												progressColor =
												android.graphics.Color.parseColor(
												"#2979FF"
												);
												
											} else {
												
												// 🟣 KESULITAN
												progressColor =
												android.graphics.Color.parseColor(
												"#D500F9"
												);
											}
											
											// ====================================================
											// BUAT DRAWABLE
											// ====================================================
											final PremiumProgressDrawable drawable =
											new PremiumProgressDrawable(
											progressColor
											);
											
											progressBar.setMax(100);
											
											progressBar.setProgressDrawable(
											drawable
											);
											
											progressBar.setProgress(0);
											
											drawable.setProgressValue(0);
											
											// ====================================================
											// 🔥 ANIMASI PENGISIAN 800ms
											// ====================================================
											final android.animation.ValueAnimator progressAnimator =
											android.animation.ValueAnimator.ofInt(
											0,
											targetValue
											);
											
											progressAnimator.setDuration(800L);
											
											progressAnimator.setInterpolator(
											new android.view.animation.DecelerateInterpolator()
											);
											
											progressAnimator.addUpdateListener(
											animation -> {
												
												if (progressBar.getProgressDrawable()
												!= drawable) {
													return;
												}
												
												int currentValue =
												((Integer)
												animation.getAnimatedValue()
												).intValue();
												
												drawable.setProgressValue(
												currentValue
												);
												
												progressBar.setProgress(
												currentValue
												);
											}
											);
											
											progressAnimator.start();
										};
										
										// ========================================================
										// 🟢 KETAHAHAN
										// ========================================================
										setupProgress.accept(
										progressDurability_kustom,
										durability
										);
										
										// ========================================================
										// 🔴 SERANGAN
										// ========================================================
										setupProgress.accept(
										progressOffense_kustom,
										offense
										);
										
										// ========================================================
										// 🔵 EFEK KONTROL
										// ========================================================
										setupProgress.accept(
										progressControl_kustom,
										control
										);
										
										// ========================================================
										// 🟣 KESULITAN
										// ========================================================
										setupProgress.accept(
										progressDifficulty_kustom,
										difficulty
										);
										
									} catch (Exception e) {
										e.printStackTrace();
									}
									
									// ========================================================
									// AVATAR KECIL
									// ========================================================
									if (imageview2_kustom != null) {
										imageview2_kustom.setScaleType(
										ImageView.ScaleType.FIT_XY
										);
										
										android.graphics.drawable.GradientDrawable strokeAvatar =
										new android.graphics.drawable.GradientDrawable();
										
										strokeAvatar.setStroke(
										(int)(1.5f * density_kustom),
										Color.WHITE
										);
										
										strokeAvatar.setCornerRadius(
										12 * density_kustom
										);
										
										imageview2_kustom.setBackground(strokeAvatar);
										imageview2_kustom.setClipToOutline(true);
									}
									
									String url_kustom = "";
									
									if (finalHeroData.containsKey("URL")) {
										url_kustom =
										String.valueOf(finalHeroData.get("URL"));
									}
									
									if (imageview2_kustom != null &&
									!url_kustom.isEmpty()) {
										
										com.bumptech.glide.Glide
										.with(getApplicationContext())
										.load(url_kustom)
										.placeholder(R.drawable.herokosong)
										.into(imageview2_kustom);
									}
									
									// ========================================================
									// BACKGROUND HERO STATS
									// ========================================================
									if (layoutHeroStats_kustom != null &&
									!url_kustom.isEmpty()) {
										
										com.bumptech.glide.Glide
										.with(getApplicationContext())
										.asBitmap()
										.load(url_kustom)
										.placeholder(R.drawable.herokosong)
										.into(
										new com.bumptech.glide.request.target.CustomTarget<android.graphics.Bitmap>() {
											
											@Override
											public void onResourceReady(
											android.graphics.Bitmap resource,
											com.bumptech.glide.request.transition.Transition<? super android.graphics.Bitmap> transition
											) {
												
												if (layoutHeroStats_kustom != null) {
													
													android.graphics.drawable.BitmapDrawable backgroundDrawable =
													new android.graphics.drawable.BitmapDrawable(
													getResources(),
													resource
													);
													
													backgroundDrawable.setAlpha(95);
													
													backgroundDrawable.setGravity(
													android.view.Gravity.FILL
													);
													
													layoutHeroStats_kustom.setBackground(
													backgroundDrawable
													);
												}
											}
											
											@Override
											public void onLoadCleared(
											android.graphics.drawable.Drawable placeholder
											) {
												
												if (layoutHeroStats_kustom != null) {
													layoutHeroStats_kustom.setBackground(null);
												}
											}
										}
										);
									}
									
									// ========================================================
									// IKON SKILL
									// ========================================================
									if (imgSkillPasif_kustom != null &&
									finalHeroData.containsKey("skill_pasif_URL")) {
										
										com.bumptech.glide.Glide
										.with(getApplicationContext())
										.load(String.valueOf(
										finalHeroData.get("skill_pasif_URL")
										))
										.placeholder(R.drawable.herokosong)
										.transform(
										new com.bumptech.glide.load.resource.bitmap.CircleCrop()
										)
										.into(imgSkillPasif_kustom);
									}
									
									if (imgSkill1_kustom != null &&
									finalHeroData.containsKey("skill1_URL")) {
										
										com.bumptech.glide.Glide
										.with(getApplicationContext())
										.load(String.valueOf(
										finalHeroData.get("skill1_URL")
										))
										.placeholder(R.drawable.herokosong)
										.transform(
										new com.bumptech.glide.load.resource.bitmap.CircleCrop()
										)
										.into(imgSkill1_kustom);
									}
									
									if (imgSkill2_kustom != null &&
									finalHeroData.containsKey("skill2_URL")) {
										
										com.bumptech.glide.Glide
										.with(getApplicationContext())
										.load(String.valueOf(
										finalHeroData.get("skill2_URL")
										))
										.placeholder(R.drawable.herokosong)
										.transform(
										new com.bumptech.glide.load.resource.bitmap.CircleCrop()
										)
										.into(imgSkill2_kustom);
									}
									
									if (imgSkillUlt_kustom != null &&
									finalHeroData.containsKey("skill_ult_URL")) {
										
										com.bumptech.glide.Glide
										.with(getApplicationContext())
										.load(String.valueOf(
										finalHeroData.get("skill_ult_URL")
										))
										.placeholder(R.drawable.herokosong)
										.transform(
										new com.bumptech.glide.load.resource.bitmap.CircleCrop()
										)
										.into(imgSkillUlt_kustom);
									}
									
									// ========================================================
									// 🚀 EVENT KLIK POP-UP SKILL
									// ========================================================
									final java.util.HashMap<String, Object> dataHeroFinalKlik =
									finalHeroData;
									
									if (imgSkillPasif_kustom != null &&
									dataHeroFinalKlik != null &&
									dataHeroFinalKlik.containsKey("skill_pasif_URL")) {
										
										imgSkillPasif_kustom.setOnTouchListener((v, event) -> {
											
											switch (event.getAction()) {
												
												case android.view.MotionEvent.ACTION_DOWN:
												
												v.animate()
												.scaleX(0.88f)
												.scaleY(0.88f)
												.setDuration(80)
												.start();
												
												break;
												
												case android.view.MotionEvent.ACTION_UP:
												
												v.animate()
												.scaleX(1f)
												.scaleY(1f)
												.setDuration(80)
												.start();
												
												String judulP = "Skill Pasif";
												String deskripsiP =
												"Deskripsi tidak tersedia.";
												
												if (dataHeroFinalKlik.containsKey("skill_desc")) {
													
													String fullDesc =
													String.valueOf(
													dataHeroFinalKlik.get("skill_desc")
													);
													
													try {
														
														String[] bagian =
														fullDesc.split("🔵");
														
														deskripsiP =
														bagian[0]
														.replace("🔴", "")
														.trim();
														
														String[] baris =
														deskripsiP.split("\n");
														
														if (baris.length > 0) {
															
															judulP =
															baris[0]
															.replace("PASIF - ", "")
															.replace(":", "")
															.trim();
														}
														
													} catch (Exception e) {
														
														deskripsiP = fullDesc;
													}
												}
												
												com.phoenix.tools.skin.security.JsonManager
												.tampilkanSkillPopup(
												_view.getContext(),
												judulP,
												deskripsiP,
												String.valueOf(
												dataHeroFinalKlik.get(
												"skill_pasif_URL"
												)
												)
												);
												
												break;
												
												case android.view.MotionEvent.ACTION_CANCEL:
												
												v.animate()
												.scaleX(1f)
												.scaleY(1f)
												.setDuration(80)
												.start();
												
												break;
											}
											
											return true;
										});
									}
									
									if (imgSkill1_kustom != null &&
									dataHeroFinalKlik != null &&
									dataHeroFinalKlik.containsKey("skill1_URL")) {
										
										imgSkill1_kustom.setOnTouchListener((v, event) -> {
											
											switch (event.getAction()) {
												
												case android.view.MotionEvent.ACTION_DOWN:
												
												v.animate()
												.scaleX(0.88f)
												.scaleY(0.88f)
												.setDuration(80)
												.start();
												
												break;
												
												case android.view.MotionEvent.ACTION_UP:
												
												v.animate()
												.scaleX(1f)
												.scaleY(1f)
												.setDuration(80)
												.start();
												
												String judul1 = "Skill 1";
												String deskripsi1 =
												"Deskripsi tidak tersedia.";
												
												if (dataHeroFinalKlik.containsKey("skill_desc")) {
													
													String fullDesc =
													String.valueOf(
													dataHeroFinalKlik.get("skill_desc")
													);
													
													try {
														
														String[] bagian1 =
														fullDesc.split("🔵");
														
														String[] bagian2 =
														bagian1[1].split("🟡");
														
														deskripsi1 =
														bagian2[0].trim();
														
														String[] baris =
														deskripsi1.split("\n");
														
														if (baris.length > 0) {
															
															judul1 =
															baris[0]
															.replace("SKILL 1 - ", "")
															.replace(":", "")
															.trim();
														}
														
													} catch (Exception e) {
														
														deskripsi1 = fullDesc;
													}
												}
												
												com.phoenix.tools.skin.security.JsonManager
												.tampilkanSkillPopup(
												_view.getContext(),
												judul1,
												deskripsi1,
												String.valueOf(
												dataHeroFinalKlik.get(
												"skill1_URL"
												)
												)
												);
												
												break;
												
												case android.view.MotionEvent.ACTION_CANCEL:
												
												v.animate()
												.scaleX(1f)
												.scaleY(1f)
												.setDuration(80)
												.start();
												
												break;
											}
											
											return true;
										});
									}
									
									if (imgSkill2_kustom != null &&
									dataHeroFinalKlik != null &&
									dataHeroFinalKlik.containsKey("skill2_URL")) {
										
										imgSkill2_kustom.setOnTouchListener((v, event) -> {
											
											switch (event.getAction()) {
												
												case android.view.MotionEvent.ACTION_DOWN:
												
												v.animate()
												.scaleX(0.88f)
												.scaleY(0.88f)
												.setDuration(80)
												.start();
												
												break;
												
												case android.view.MotionEvent.ACTION_UP:
												
												v.animate()
												.scaleX(1f)
												.scaleY(1f)
												.setDuration(80)
												.start();
												
												String judul2 = "Skill 2";
												String deskripsi2 =
												"Deskripsi tidak tersedia.";
												
												if (dataHeroFinalKlik.containsKey("skill_desc")) {
													
													String fullDesc =
													String.valueOf(
													dataHeroFinalKlik.get("skill_desc")
													);
													
													try {
														
														String[] bagian1 =
														fullDesc.split("🟡");
														
														String[] bagian2 =
														bagian1[1].split("💜");
														
														deskripsi2 =
														bagian2[0].trim();
														
														String[] baris =
														deskripsi2.split("\n");
														
														if (baris.length > 0) {
															
															judul2 =
															baris[0]
															.replace("SKILL 2 - ", "")
															.replace(":", "")
															.trim();
														}
														
													} catch (Exception e) {
														
														deskripsi2 = fullDesc;
													}
												}
												
												com.phoenix.tools.skin.security.JsonManager
												.tampilkanSkillPopup(
												_view.getContext(),
												judul2,
												deskripsi2,
												String.valueOf(
												dataHeroFinalKlik.get(
												"skill2_URL"
												)
												)
												);
												
												break;
												
												case android.view.MotionEvent.ACTION_CANCEL:
												
												v.animate()
												.scaleX(1f)
												.scaleY(1f)
												.setDuration(80)
												.start();
												
												break;
											}
											
											return true;
										});
									}
									
									if (imgSkillUlt_kustom != null &&
									dataHeroFinalKlik != null &&
									dataHeroFinalKlik.containsKey("skill_ult_URL")) {
										
										imgSkillUlt_kustom.setOnTouchListener((v, event) -> {
											
											switch (event.getAction()) {
												
												case android.view.MotionEvent.ACTION_DOWN:
												
												v.animate()
												.scaleX(0.88f)
												.scaleY(0.88f)
												.setDuration(80)
												.start();
												
												break;
												
												case android.view.MotionEvent.ACTION_UP:
												
												v.animate()
												.scaleX(1f)
												.scaleY(1f)
												.setDuration(80)
												.start();
												
												String judulU = "Ultimate Skill";
												String deskripsiU =
												"Deskripsi tidak tersedia.";
												
												if (dataHeroFinalKlik.containsKey("skill_desc")) {
													
													String fullDesc =
													String.valueOf(
													dataHeroFinalKlik.get("skill_desc")
													);
													
													try {
														
														String[] bagian =
														fullDesc.split("💜");
														
														deskripsiU =
														bagian[1].trim();
														
														String[] baris =
														deskripsiU.split("\n");
														
														if (baris.length > 0) {
															
															judulU =
															baris[0]
															.replaceAll(
															"ULTIMATE \\(SKILL \\d+\\) - ",
															""
															)
															.replace(":", "")
															.trim();
														}
														
													} catch (Exception e) {
														
														deskripsiU = fullDesc;
													}
												}
												
												com.phoenix.tools.skin.security.JsonManager
												.tampilkanSkillPopup(
												_view.getContext(),
												judulU,
												deskripsiU,
												String.valueOf(
												dataHeroFinalKlik.get(
												"skill_ult_URL"
												)
												)
												);
												
												break;
												
												case android.view.MotionEvent.ACTION_CANCEL:
												
												v.animate()
												.scaleX(1f)
												.scaleY(1f)
												.setDuration(80)
												.start();
												
												break;
											}
											
											return true;
										});
									}
								}
								
							} catch(Exception e) {}
							
						}
						
						return; 
					}
					
					// ========================================================
					// 🔥 STEP 2: LOGIKA SKIN INDEKS BAWAH
					// ========================================================
					if (com.phoenix.tools.skin.security.JsonManager.handleSkinVisibility(
					getApplicationContext(),
					_view,
					linear1
					)) {
						
						return;
					}
					
					linear1.setVisibility(View.VISIBLE);
					
					// Jika ada detail hero atas, indeks data skin digeser mundur 1 baris
					final int skinPos =
					apakahHeroAdaDiGitHub ? (pos - 1) : pos;
					
					if (_view instanceof android.widget.LinearLayout) {
						
						android.widget.LinearLayout mainRowLayout =
						(android.widget.LinearLayout) _view;
						
						mainRowLayout.setOrientation(
						android.widget.LinearLayout.HORIZONTAL
						);
						
						// ANTI-AMBLAS
						if (headerView_kustom != null &&
						headerView_kustom.getParent() == mainRowLayout) {
							
							mainRowLayout.removeView(headerView_kustom);
						}
					}
					
					// ========================================================
					// DEKORASI BOKS LIST SKIN
					// ========================================================
					linear1.setBackground(
					new android.graphics.drawable.GradientDrawable() {
						
						public android.graphics.drawable.GradientDrawable getIns(
						int a,
						int b,
						int c,
						int d
						) {
							
							this.setCornerRadius(a);
							this.setStroke(b, c);
							this.setColor(d);
							
							return this;
						}
						
					}.getIns(
					(int)20,
					(int)2,
					0xFF212121,
					0xFFE0E0E0
					)
					);
					
					// ========================================================
					// PENGECEKAN DATA SKIN
					// ========================================================
					if (skinPos >= 0 && skinPos < _data.size()) {
						
						if (imageview1 != null) {
							
							imageview1.setScaleType(
							ImageView.ScaleType.CENTER_CROP
							); 
						}
						
						if (_data.size() > skinPos &&
						_data.get(skinPos).containsKey("img2") &&
						_data.get(skinPos).get("img2") != null) {
							
							com.bumptech.glide.Glide
							.with(getApplicationContext())
							.load(_data.get(skinPos).get("img2").toString())
							.placeholder(R.drawable.herokosong)
							.diskCacheStrategy(
							com.bumptech.glide.load.engine.DiskCacheStrategy.ALL
							)
							.dontAnimate()
							.transform(
							new com.bumptech.glide.load.resource.bitmap.CenterCrop(),
							new com.bumptech.glide.load.resource.bitmap.RoundedCorners(20)
							)
							.into(imageview1);
						}
						
						// ========================================================
						// TEXT SKIN
						// ========================================================
						if (textview1 != null) {
							
							textview1.setTypeface(
							Typeface.createFromAsset(
							getAssets(),
							"fonts/quick.ttf"
							),
							1
							);
							
							textview1.setTextSize(
							TypedValue.COMPLEX_UNIT_DIP,
							11
							);
							
							textview1.setGravity(
							android.view.Gravity.CENTER
							);
						}
						
						if (linear1 instanceof android.widget.LinearLayout) {
							
							((android.widget.LinearLayout) linear1)
							.setGravity(android.view.Gravity.CENTER);
						}
						
						if (skinPos == 0) {
							
							// Skin urutan pertama = Backup Hero
							if (textview1 != null) {
								
								textview1.clearAnimation();
								
								textview1.setEllipsize(
								TextUtils.TruncateAt.END
								);
								
								textview1.setSelected(false);
								
								textview1.setText(
								"Backup ".concat(
								sp.getString("her", "")
								)
								);
								
								textview1.setVisibility(View.VISIBLE);
							}
							
						} else {
							
							if (_data.size() > skinPos &&
							_data.get(skinPos).containsKey("skin_name") &&
							_data.get(skinPos).get("skin_name") != null) {
								
								if (textview1 != null) {
									
									textview1.clearAnimation();
									
									textview1.setText(
									String.valueOf(
									_data.get(skinPos).get("skin_name")
									)
									);
									
									if (!textview1.isSelected()) {
										textview1.setSelected(true);
									}
									
									textview1.setVisibility(View.VISIBLE);
								}
							}
						}
						
						// ========================================================
						// EFFECT SENTUHAN PREMIUM
						// ========================================================
						View.OnTouchListener anim = (v, event) -> {
							
							switch (event.getAction()) {
								
								case MotionEvent.ACTION_DOWN:
								
								v.animate()
								.scaleX(0.92f)
								.scaleY(0.92f)
								.setDuration(100)
								.start();
								
								break;
								
								case MotionEvent.ACTION_UP:
								case MotionEvent.ACTION_CANCEL:
								
								v.animate()
								.scaleX(1f)
								.scaleY(1f)
								.setDuration(100)
								.start();
								
								break;
							}
							
							return false;
						};
						
						if (imageview1 != null) {
							imageview1.setOnTouchListener(anim);
						}
						
						// ========================================================
						// LOGIKA SELESAI UNDUH & PERIZINAN INJEKSI SKIN
						// ========================================================
						imageview1.setOnClickListener(v -> {
							
							// 🟢 KUNCI EMAS FIX LANDSCAPE
							final android.app.Activity currentActivity =
							HeroskinActivity.this;
							
							// 🟢 VALIDASI DATA SKIN
							if (skinPos < _data.size() &&
							_data.get(skinPos).containsKey("url") &&
							_data.get(skinPos).get("url") != null) {
								
								PermissionManager perm =
								new PermissionManager(currentActivity);
								
								String mode =
								sp.getString("DOWNLOAD_MODE", "");
								
								final String url =
								String.valueOf(
								_data.get(skinPos).get("url")
								);
								
								final String fileName =
								String.valueOf(
								_data.get(skinPos).get("skin_name")
								) + ".zip";
								
								// ====================================================
								// PENGECEKAN MODE DOWNLOAD
								// ====================================================
								if (mode.equals("")) {
									
									_showModeDialog();
									return;
								}
								
								if (mode.equals("DEFAULT")) {
									
									if (!perm.IsPermissionGranted()) {
										
										sp.edit()
										.putString("DOWNLOAD_MODE", "")
										.apply();
										
										Toast.makeText(
										currentActivity.getApplicationContext(),
										"Membuka izin folder...",
										Toast.LENGTH_SHORT
										).show();
										
										perm.RequestDataPermission();
										
										return;
									}
								} 
								
								if (mode.equals("SHIZUKU")) {
									
									if (fyy == null ||
									!fyy.isShizukuInstalled()) {
										
										Toast.makeText(
										currentActivity.getApplicationContext(),
										"Shizuku belum terinstall / belum siap",
										Toast.LENGTH_SHORT
										).show();
										
										return;
									}
									
									boolean hasPerm = false;
									
									try {
										hasPerm = fyy.hasPermission();
									} catch (Exception e) {
										hasPerm = false;
									}
									
									if (!hasPerm) {
										
										fyy.requestPermission();
										
										Toast.makeText(
										currentActivity.getApplicationContext(),
										"Klik 'Allow' lalu klik lagi untuk mendownload",
										Toast.LENGTH_SHORT
										).show();
										
										return; 
									}
								}
								
								if (mode.equals("IADB")) {
									
									Toast.makeText(
									currentActivity.getApplicationContext(),
									"Fitur iAdb segera hadir di pembaruan mendatang! 🚀",
									Toast.LENGTH_LONG
									).show();
									
									return;
								}
								
								// ====================================================
								// AKSI DOWNLOAD
								// ====================================================
								Runnable startDownload = () -> {
									
									if (!currentActivity.isFinishing() &&
									!currentActivity.isDestroyed()) {
										
										if (mode.equals("DEFAULT")) {
											
											new DefaultDownloader(currentActivity)
											.startDownload(
											url,
											fileName
											);
											
										} else if (mode.equals("SHIZUKU")) {
											
											new ShizukuDownloader(
											currentActivity,
											fyy
											).startDownload(
											url,
											fileName
											);
										}
									}
								};
								
								ZeroAdsManager.showAd(
								currentActivity,
								startDownload
								);
							}
						});
					}
				}
			}
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}