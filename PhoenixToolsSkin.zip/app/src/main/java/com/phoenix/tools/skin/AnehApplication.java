package com.phoenix.tools.skin;

import android.app.Application;
import android.content.Intent;
import android.util.Log;

public class AnehApplication extends Application {

    private Thread.UncaughtExceptionHandler defaultExceptionHandler;

    // 🌟 SAKLAR KONTROL IKLAN
    public static boolean isSplashActive = true;

    @Override
    public void onCreate() {
        super.onCreate();

        // ===== 🛡️ SETUP CRASH HANDLER (SISTEM DEBUGACTIVITY ANDALANMU) =====
        defaultExceptionHandler = Thread.getDefaultUncaughtExceptionHandler();

        Thread.setDefaultUncaughtExceptionHandler((thread, throwable) -> {
            try {
                // Mengamankan Intent DebugActivity menggunakan flag NEW_TASK yang sah
                Intent intent = new Intent(getApplicationContext(), DebugActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                intent.putExtra("error", Log.getStackTraceString(throwable));
                startActivity(intent);
            } catch (Exception e) {
                Log.e("AnehApplication", "Gagal mengalihkan ke DebugActivity: " + e.getMessage());
            }

            if (defaultExceptionHandler != null) {
                defaultExceptionHandler.uncaughtException(thread, throwable);
            }
        });
    }
}
