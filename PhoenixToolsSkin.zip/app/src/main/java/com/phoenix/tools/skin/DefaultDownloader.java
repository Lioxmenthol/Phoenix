package com.phoenix.tools.skin;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.PowerManager;
import android.provider.DocumentsContract;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import android.graphics.drawable.GradientDrawable;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.animation.ObjectAnimator;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;

import androidx.documentfile.provider.DocumentFile;

import com.kaopiz.kprogresshud.KProgressHUD;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class DefaultDownloader {

    private Activity activity;
    private SharedPreferences sp;
    private LayoutInflater inflater;
    private static boolean isDownloading = false;

    // ======================================
    // MODERN TOAST CONTROLLER
    // ======================================

    private final Handler toastHandler =
            new Handler(Looper.getMainLooper());

    private View activeToast;

    private ObjectAnimator progressAnimator;
    private ObjectAnimator mascotAnimator;

    private Runnable hideToastRunnable;

    // ======================================
    // CONSTRUCTOR
    // ======================================

    public DefaultDownloader(Activity activity) {

        this.activity = activity;
        this.inflater = activity.getLayoutInflater();

        // DISINKRONKAN: Membaca preference default Sketchware
        this.sp = activity.getSharedPreferences(
                activity.getPackageName() + "_preferences",
                Activity.MODE_PRIVATE
        );
    }

    // ======================================
    // ACTIVITY SAFETY
    // ======================================

    private boolean isActivityAlive() {

        return activity != null
                && !activity.isFinishing()
                && !activity.isDestroyed();
    }

    private int dp(float value) {

        return (int) (
                value * activity.getResources()
                        .getDisplayMetrics().density + 0.5f
        );
    }

    // ======================================
    // START DOWNLOAD
    // ======================================

    public void startDownload(String url, String zipName) {

        if (isDownloading) {

            Toast.makeText(
                    activity,
                    "Masih ada download yang berjalan...",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        new DownloadTask(url, zipName).execute();
    }

    // ======================================
    // FORMAT SIZE
    // ======================================

    private static String formatSize(long bytes) {

        if (bytes <= 0) return "0 B";

        String[] units = {"B", "KB", "MB", "GB"};

        int digit = 0;
        double size = bytes;

        while (size >= 1024 && digit < units.length - 1) {

            size /= 1024;
            digit++;
        }

        return String.format("%.2f %s", size, units[digit]);
    }

    private static String formatSpeed(long bytesPerSec) {

        return formatSize(bytesPerSec) + "/s";
    }

    private static String formatTime(long second) {

        return String.format(
                "%02d:%02d",
                second / 60,
                second % 60
        );
    }

    // ======================================
    // DOWNLOAD TASK
    // ======================================

    private class DownloadTask extends AsyncTask<ProgressData, ProgressData, String> {

        private String downloadUrl;
        private String zipName;

        private ProgressBar progressBar;

        private TextView txtTitle;
        private TextView txtPercent;
        private TextView txtSize;
        private TextView txtSpeed;
        private TextView txtEta;

        private KProgressHUD hud;

        private PowerManager.WakeLock wakeLock;

        DownloadTask(String url, String file) {

            this.downloadUrl = url;
            this.zipName = file;
        }

        // ======================================
        // PRE EXECUTE
        // ======================================

        @Override
        protected void onPreExecute() {

            isDownloading = true;

            PowerManager pm = (PowerManager)
                    activity.getSystemService(Activity.POWER_SERVICE);

            wakeLock = pm.newWakeLock(
                    PowerManager.PARTIAL_WAKE_LOCK,
                    "DEFAULT:DownloadLock"
            );

            wakeLock.acquire(10 * 60 * 1000L);

            View v = inflater.inflate(R.layout.ext, null);

            LinearLayout linear = v.findViewById(R.id.linear2);

            progressBar = v.findViewById(R.id.progressbar1);

            txtTitle = v.findViewById(R.id.txtTitle);

            txtPercent = v.findViewById(R.id.textviewer);

            txtSize = v.findViewById(R.id.txtSize);

            txtSpeed = v.findViewById(R.id.txtSpeed);

            txtEta = v.findViewById(R.id.txtEta);

            GradientDrawable bg = new GradientDrawable();

            bg.setColor(0xFF000000);
            bg.setCornerRadius(30);
            bg.setStroke(4, 0xFFFFFFFF);

            linear.setBackground(bg);

            progressBar.setMax(100);
            progressBar.setProgress(0);

            // ======================================
            // PROGRESS BAR BACKGROUND
            // ======================================

            android.graphics.drawable.GradientDrawable progressBg =
                    new android.graphics.drawable.GradientDrawable();

            progressBg.setColor(0x33FFFFFF);
            progressBg.setStroke(2, 0xFFFFFFFF);
            progressBg.setCornerRadius(10);

            // ======================================
            // PROGRESS BAR FILL
            // ======================================

            android.graphics.drawable.GradientDrawable progressFill =
                    new android.graphics.drawable.GradientDrawable();

            progressFill.setColor(0xFFFFFFFF);
            progressFill.setCornerRadius(10);

            // ======================================
            // LAYER DRAWABLE
            // ======================================

            android.graphics.drawable.Drawable[] layers =
                    new android.graphics.drawable.Drawable[] {

                            progressBg,

                            new android.graphics.drawable.ScaleDrawable(
                                    progressFill,
                                    android.view.Gravity.LEFT,
                                    1.0f,
                                    -1.0f
                            )
                    };

            android.graphics.drawable.LayerDrawable finalDrawable =
                    new android.graphics.drawable.LayerDrawable(layers);

            finalDrawable.setId(0, android.R.id.background);

            finalDrawable.setId(1, android.R.id.progress);

            progressBar.setProgressDrawable(finalDrawable);

            // ======================================
            // INITIAL TEXT
            // ======================================

            txtTitle.setText("Preparing...");

            txtPercent.setText("0%");

            txtSize.setText("0 B / 0 B");

            txtSpeed.setText("0 KB/s");

            txtEta.setText("Remaining --:--");

            // ======================================
            // HUD
            // ======================================

            hud = KProgressHUD.create(activity)
                    .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                    .setCustomView(v)
                    .setCancellable(false);

            hud.show();

            try {

                android.view.ViewParent vp = v.getParent();

                while (vp instanceof android.view.View) {

                    android.view.View parentView =
                            (android.view.View) vp;

                    parentView.setBackgroundColor(
                            android.graphics.Color.TRANSPARENT
                    );

                    parentView.setPadding(0, 0, 0, 0);

                    vp = parentView.getParent();
                }

            } catch (Exception e) {

                e.printStackTrace();
            }
        }

        // ======================================
        // BACKGROUND DOWNLOAD
        // ======================================

        @Override
        protected String doInBackground(ProgressData... params) {

            try {

                String uriString = sp.getString("D_URI", "");

                if (uriString.isEmpty()) {

                    return "Permission tidak valid";
                }

                Uri treeUri = Uri.parse(uriString);

                DocumentFile root =
                        DocumentFile.fromTreeUri(activity, treeUri);

                if (root == null) {

                    return "Folder tidak valid";
                }

                publishProgress(
                        ProgressData.createTitleUpdate("Connecting...")
                );

                HttpURLConnection conn =
                        (HttpURLConnection) new URL(downloadUrl)
                                .openConnection();

                conn.setConnectTimeout(15000);

                conn.setReadTimeout(15000);

                conn.connect();

                if (conn.getResponseCode() != HttpURLConnection.HTTP_OK) {

                    return "HTTP " + conn.getResponseCode();
                }

                long totalBytes = conn.getContentLengthLong();

                InputStream input = conn.getInputStream();

                // ======================================
                // DOWNLOAD KE INTERNAL CACHE
                // ======================================

                java.io.File localCacheDir = activity.getCacheDir();

                java.io.File tempZipFile =
                        new java.io.File(localCacheDir, zipName);

                java.io.FileOutputStream out =
                        new java.io.FileOutputStream(tempZipFile);

                byte[] buffer = new byte[131072];

                int len;

                long downloadedBytes = 0;

                long lastTime = System.currentTimeMillis();

                long lastBytes = 0;

                publishProgress(
                        ProgressData.createTitleUpdate("Downloading...")
                );

                while ((len = input.read(buffer)) != -1) {

                    out.write(buffer, 0, len);

                    downloadedBytes += len;

                    long now = System.currentTimeMillis();

                    if (now - lastTime >= 1000) {

                        long speed = downloadedBytes - lastBytes;

                        long eta = (speed > 0)
                                ? (totalBytes - downloadedBytes) / speed
                                : 0;

                        int percent = (totalBytes > 0)
                                ? (int) (downloadedBytes * 100L / totalBytes)
                                : 0;

                        publishProgress(
                                ProgressData.createProgressUpdate(
                                        percent,
                                        downloadedBytes,
                                        totalBytes,
                                        speed,
                                        eta
                                )
                        );

                        lastBytes = downloadedBytes;

                        lastTime = now;
                    }
                }

                out.flush();

                out.close();

                input.close();

                conn.disconnect();

                publishProgress(
                        ProgressData.createProgressUpdate(
                                100,
                                totalBytes,
                                totalBytes,
                                0,
                                0
                        )
                );

                publishProgress(
                        ProgressData.createTitleUpdate("Extracting...")
                );

                // ======================================
                // EKSTRAKSI SECARA LOKAL
                // ======================================

                java.io.File localExtractDir =
                        new java.io.File(
                                localCacheDir,
                                "extracted_skin_" + System.currentTimeMillis()
                        );

                if (!localExtractDir.exists()) {

                    localExtractDir.mkdirs();
                }

                java.io.FileInputStream fis =
                        new java.io.FileInputStream(tempZipFile);

                ZipInputStream zis =
                        new ZipInputStream(
                                new java.io.BufferedInputStream(fis, 131072)
                        );

                ZipEntry entry;

                while ((entry = zis.getNextEntry()) != null) {

                    java.io.File outFile =
                            new java.io.File(
                                    localExtractDir,
                                    entry.getName()
                            );

                    if (entry.isDirectory()) {

                        outFile.mkdirs();

                    } else {

                        java.io.File parent = outFile.getParentFile();

                        if (parent != null && !parent.exists()) {

                            parent.mkdirs();
                        }

                        java.io.BufferedOutputStream bos =
                                new java.io.BufferedOutputStream(
                                        new java.io.FileOutputStream(outFile),
                                        131072
                                );

                        int count;

                        while ((count = zis.read(buffer)) != -1) {

                            bos.write(buffer, 0, count);
                        }

                        bos.flush();

                        bos.close();
                    }

                    zis.closeEntry();
                }

                zis.close();

                fis.close();

                // HAPUS ZIP TEMP SETELAH DIEKSTRAK
                tempZipFile.delete();

                // ======================================
                // SALIN HASIL EKSTRAKSI KE SAF
                // ======================================

                publishProgress(
                        ProgressData.createTitleUpdate("Proccess...")
                );

                int[] fileCounter = new int[]{0};

                copyLocalFolderToSAF(
                        localExtractDir,
                        root,
                        fileCounter
                );

                // ======================================
                // BERSIHKAN CACHE LOKAL
                // ======================================

                deleteLocalFolder(localExtractDir);

                return "OK";

            } catch (Exception e) {

                return e.toString();
            }
        }

        // ======================================
        // COPY LOCAL FOLDER TO SAF
        // ======================================

        private void copyLocalFolderToSAF(
                java.io.File localDir,
                DocumentFile safDir,
                int[] counter
        ) throws Exception {

            java.io.File[] files = localDir.listFiles();

            if (files == null) return;

            for (java.io.File file : files) {

                if (file.isDirectory()) {

                    DocumentFile nextSafDir =
                            safDir.findFile(file.getName());

                    if (nextSafDir == null
                            || !nextSafDir.isDirectory()) {

                        nextSafDir =
                                safDir.createDirectory(file.getName());
                    }

                    if (nextSafDir != null) {

                        copyLocalFolderToSAF(
                                file,
                                nextSafDir,
                                counter
                        );
                    }

                } else {

                    // ======================================
                    // METODE ZARCHIVER: TARGET & TIMPA (wt)
                    // ======================================

                    Uri parentUri = safDir.getUri();

                    String parentDocId =
                            DocumentsContract.getDocumentId(parentUri);

                    String childDocId =
                            parentDocId + "/" + Uri.encode(file.getName());

                    Uri fileTargetUri =
                            DocumentsContract.buildDocumentUriUsingTree(
                                    parentUri,
                                    childDocId
                            );

                    OutputStream out = null;

                    try {

                        out = activity.getContentResolver()
                                .openOutputStream(fileTargetUri, "wt");

                    } catch (Exception e) {

                        // BUAT FILE BARU JIKA TARGET BELUM ADA

                        DocumentFile newSafFile =
                                safDir.createFile("*/*", file.getName());

                        if (newSafFile != null) {

                            out = activity.getContentResolver()
                                    .openOutputStream(newSafFile.getUri());
                        }
                    }

                    if (out != null) {

                        java.io.FileInputStream in =
                                new java.io.FileInputStream(file);

                        java.io.BufferedOutputStream bos =
                                new java.io.BufferedOutputStream(
                                        out,
                                        131072
                                );

                        byte[] buf = new byte[131072];

                        int len;

                        while ((len = in.read(buf)) != -1) {

                            bos.write(buf, 0, len);
                        }

                        bos.flush();

                        bos.close();

                        out.close();

                        in.close();

                        counter[0]++;

                        publishProgress(
                                ProgressData.createExtractUpdate(
                                        -1,
                                        counter[0],
                                        0
                                )
                        );
                    }
                }
            }
        }

        // ======================================
        // DELETE LOCAL FOLDER
        // ======================================

        private void deleteLocalFolder(java.io.File folder) {

            java.io.File[] files = folder.listFiles();

            if (files != null) {

                for (java.io.File f : files) {

                    if (f.isDirectory()) {

                        deleteLocalFolder(f);

                    } else {

                        f.delete();
                    }
                }
            }

            folder.delete();
        }

        // ======================================
        // PROGRESS UPDATE
        // ======================================

        @Override
        protected void onProgressUpdate(ProgressData... values) {

            ProgressData data = values[0];

            if (data.type == ProgressData.TYPE_TITLE) {

                txtTitle.setText(data.title);

            } else if (data.type == ProgressData.TYPE_DOWNLOAD) {

                progressBar.setIndeterminate(false);

                progressBar.setProgress(data.percent);

                txtPercent.setText(data.percent + "%");

                txtSize.setText(
                        formatSize(data.current)
                                + " / "
                                + formatSize(data.total)
                );

                txtSpeed.setText(formatSpeed(data.speed));

                txtEta.setText(
                        "Remaining " + formatTime(data.eta)
                );

            } else if (data.type == ProgressData.TYPE_EXTRACT) {

                progressBar.setIndeterminate(true);

                txtPercent.setText("Download");

                txtSize.setText(
                        "Installing: " + data.current + " Files..."
                );

                txtSpeed.setText("Extracting...");

                txtEta.setText("");
            }
        }

        // ======================================
        // POST EXECUTE
        // ======================================

        @Override
        protected void onPostExecute(String result) {

            if (hud != null && hud.isShowing()) {

                hud.dismiss();
            }

            if (wakeLock != null && wakeLock.isHeld()) {

                wakeLock.release();
            }

            isDownloading = false;

            if (result.equals("OK")) {

                // MODERN TOAST SUCCESS

                showModernToast(
                        "Success!",
                        "Download dan instalasi skin berhasil!"
                );

            } else {

                // ERROR TOAST ASLI

                Toast.makeText(
                        activity,
                        result,
                        Toast.LENGTH_LONG
                ).show();
            }
        }
    }

    // ======================================
    // MODERN SUCCESS TOAST
    // ======================================

    private void showModernToast(
            String judul,
            String pesan
    ) {

        if (!isActivityAlive()) return;

        // HAPUS TOAST SEBELUMNYA

        removeActiveToast();

        final FrameLayout decorView =
                (FrameLayout) activity.getWindow().getDecorView();

        final View toastView =
                activity.getLayoutInflater().inflate(
                        R.layout.modern_toast,
                        null,
                        false
                );

        // ======================================
        // FIND VIEW
        // ======================================

        LinearLayout card_container =
                (LinearLayout) toastView.findViewById(
                        R.id.card_container
                );

        LinearLayout icon_bg =
                (LinearLayout) toastView.findViewById(
                        R.id.icon_bg
                );

        ImageView img_check =
                (ImageView) toastView.findViewById(
                        R.id.img_check
                );

        ImageView img_mascot =
                (ImageView) toastView.findViewById(
                        R.id.img_mascot
                );

        TextView txt_title =
                (TextView) toastView.findViewById(
                        R.id.txt_title
                );

        TextView txt_desc =
                (TextView) toastView.findViewById(
                        R.id.txt_desc
                );

        ProgressBar progress_timer =
                (ProgressBar) toastView.findViewById(
                        R.id.progress_timer
                );

        // ======================================
        // SET TEXT
        // ======================================

        txt_title.setText(judul);

        txt_desc.setText(pesan);

        // ======================================
        // CARD DESIGN
        // ======================================

        GradientDrawable bgCard = new GradientDrawable();

        bgCard.setColor(Color.parseColor("#000000"));

        bgCard.setCornerRadius(dp(28));

        bgCard.setStroke(
                dp(2),
                Color.parseColor("#76FF03")
        );

        card_container.setBackground(bgCard);

        card_container.setElevation(dp(16));

        // ======================================
        // SUCCESS ICON
        // ======================================

        GradientDrawable bgIcon = new GradientDrawable();

        bgIcon.setColor(Color.parseColor("#76FF03"));

        bgIcon.setShape(GradientDrawable.OVAL);

        icon_bg.setBackground(bgIcon);

        img_check.setColorFilter(
                Color.BLACK,
                PorterDuff.Mode.SRC_IN
        );

        // ======================================
        // MASCOT IMAGE
        // ======================================

        img_mascot.setImageResource(
                R.drawable.img_mascot
        );

        img_mascot.setVisibility(View.VISIBLE);

        img_mascot.setAlpha(0f);

        img_mascot.setTranslationY(dp(5));

        // ======================================
        // PROGRESS BAR
        // ======================================

        progress_timer.setIndeterminate(false);

        progress_timer.setMax(100);

        progress_timer.setProgress(100);

        if (progress_timer.getProgressDrawable() != null) {

            progress_timer.getProgressDrawable()
                    .mutate()
                    .setColorFilter(
                            Color.parseColor("#76FF03"),
                            PorterDuff.Mode.SRC_IN
                    );
        }

        // ======================================
        // LAYOUT
        // ======================================

        FrameLayout.LayoutParams params =
                new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                );

        params.gravity = Gravity.TOP;

        params.topMargin = dp(60);

        // ======================================
        // ADD TO WINDOW
        // ======================================

        try {

            decorView.addView(toastView, params);

            activeToast = toastView;

        } catch (Exception e) {

            return;
        }

        // ======================================
        // ENTRANCE ANIMATION
        // ======================================

        toastView.setTranslationY(-dp(300));

        toastView.setAlpha(0f);

        toastView.animate()
                .translationY(0f)
                .alpha(1f)
                .setDuration(400)
                .setInterpolator(
                        new DecelerateInterpolator()
                )
                .start();

        // ======================================
        // SUCCESS ICON BOUNCE
        // ======================================

        icon_bg.setScaleX(0f);

        icon_bg.setScaleY(0f);

        icon_bg.animate()
                .scaleX(1f)
                .scaleY(1f)
                .setStartDelay(150)
                .setDuration(450)
                .setInterpolator(
                        new OvershootInterpolator(2.5f)
                )
                .start();

        // ======================================
        // MASCOT FADE IN + FLOATING
        // ======================================

        img_mascot.animate()
                .alpha(1f)
                .translationY(0f)
                .setStartDelay(200)
                .setDuration(350)
                .withEndAction(new Runnable() {

                    @Override
                    public void run() {

                        if (activeToast != toastView) return;

                        mascotAnimator = ObjectAnimator.ofFloat(
                                img_mascot,
                                View.TRANSLATION_Y,
                                0f,
                                -dp(4),
                                0f
                        );

                        mascotAnimator.setDuration(1800);

                        mascotAnimator.setRepeatCount(
                                ObjectAnimator.INFINITE
                        );

                        mascotAnimator.setInterpolator(
                                new LinearInterpolator()
                        );

                        mascotAnimator.start();
                    }
                })
                .start();

        // ======================================
        // PROGRESS ANIMATION
        // ======================================

        progressAnimator = ObjectAnimator.ofInt(
                progress_timer,
                "progress",
                100,
                0
        );

        progressAnimator.setDuration(3000);

        progressAnimator.setInterpolator(
                new LinearInterpolator()
        );

        progressAnimator.start();

        // ======================================
        // AUTO DISMISS
        // ======================================

        hideToastRunnable = new Runnable() {

            @Override
            public void run() {

                if (activeToast != toastView) return;

                if (!isActivityAlive()) {

                    removeActiveToast();

                    return;
                }

                toastView.animate()
                        .translationY(-dp(300))
                        .alpha(0f)
                        .setDuration(350)
                        .withEndAction(new Runnable() {

                            @Override
                            public void run() {

                                if (activeToast == toastView) {

                                    removeActiveToast();
                                }
                            }
                        })
                        .start();
            }
        };

        toastHandler.postDelayed(
                hideToastRunnable,
                3000
        );
    }

    // ======================================
    // REMOVE ACTIVE TOAST
    // ======================================

    private void removeActiveToast() {

        // BATALKAN CALLBACK TOAST

        if (hideToastRunnable != null) {

            toastHandler.removeCallbacks(
                    hideToastRunnable
            );

            hideToastRunnable = null;
        }

        // HENTIKAN PROGRESS ANIMATOR

        if (progressAnimator != null) {

            progressAnimator.cancel();

            progressAnimator = null;
        }

        // HENTIKAN ANIMASI MASKOT

        if (mascotAnimator != null) {

            mascotAnimator.cancel();

            mascotAnimator = null;
        }

        // HAPUS TOAST DARI WINDOW

        if (activeToast != null) {

            View oldToast = activeToast;

            activeToast = null;

            oldToast.animate().cancel();

            if (oldToast.getParent() instanceof ViewGroup) {

                try {

                    ((ViewGroup) oldToast.getParent())
                            .removeView(oldToast);

                } catch (Exception e) {
                }
            }
        }
    }

    // ======================================
    // CLEANUP ACTIVITY
    // ======================================

    public void cleanup() {

        removeActiveToast();
    }

    // ======================================
    // PROGRESS DATA
    // ======================================

    private static class ProgressData {

        static final int TYPE_TITLE = 0;

        static final int TYPE_DOWNLOAD = 1;

        static final int TYPE_EXTRACT = 2;

        int type;

        String title;

        int percent;

        long current;

        long total;

        long speed;

        long eta;

        static ProgressData createTitleUpdate(String title) {

            ProgressData d = new ProgressData();

            d.type = TYPE_TITLE;

            d.title = title;

            return d;
        }

        static ProgressData createProgressUpdate(
                int percent,
                long current,
                long total,
                long speed,
                long eta
        ) {

            ProgressData d = new ProgressData();

            d.type = TYPE_DOWNLOAD;

            d.percent = percent;

            d.current = current;

            d.total = total;

            d.speed = speed;

            d.eta = eta;

            return d;
        }

        static ProgressData createExtractUpdate(
                int percent,
                long currentFiles,
                long totalFiles
        ) {

            ProgressData d = new ProgressData();

            d.type = TYPE_EXTRACT;

            d.percent = percent;

            d.current = currentFiles;

            d.total = totalFiles;

            return d;
        }
    }
}
