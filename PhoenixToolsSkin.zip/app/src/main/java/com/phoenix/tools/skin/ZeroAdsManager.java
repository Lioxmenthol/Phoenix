package com.phoenix.tools.skin;

import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;

import com.unity3d.ads.IUnityAdsInitializationListener;
import com.unity3d.ads.IUnityAdsLoadListener;
import com.unity3d.ads.IUnityAdsShowListener;
import com.unity3d.ads.UnityAds;
import com.unity3d.ads.UnityAdsShowOptions;

public class ZeroAdsManager {

    private static boolean isAdReady = false;
    private static boolean isLoading = false;

    // ID Unity Ads
    private static final String UNITY_GAME_ID = "800446227";
    private static final String PLACEMENT_ID = "BP_Rewarded_Android";
    // Ubah ke false sebelum rilis ke Play Store
    private static final boolean TEST_MODE = true;

    // 1. FUNGSI MUAT IKLAN DI LATAR BELAKANG (PRE-LOAD)
    public static void loadAd(final Context context) {
        if (isAdReady || isLoading) {
            return;
        }

        if (!UnityAds.isInitialized()) {
            isLoading = true;
            UnityAds.initialize(context.getApplicationContext(), UNITY_GAME_ID, TEST_MODE, new IUnityAdsInitializationListener() {
                @Override
                public void onInitializationComplete() {
                    startLoadingRewarded();
                }

                @Override
                public void onInitializationFailed(UnityAds.UnityAdsInitializationError error, String message) {
                    isAdReady = false;
                    isLoading = false;
                }
            });
        } else {
            startLoadingRewarded();
        }
    }

    private static void startLoadingRewarded() {
        isLoading = true;
        UnityAds.load(PLACEMENT_ID, new IUnityAdsLoadListener() {
            @Override
            public void onUnityAdsAdLoaded(String placementId) {
                isAdReady = true;
                isLoading = false;
            }

            @Override
            public void onUnityAdsFailedToLoad(String placementId, UnityAds.UnityAdsLoadError error, String message) {
                isAdReady = false;
                isLoading = false;
            }
        });
    }

    // 2. FUNGSI TAMPIL IKLAN REWARDED UNIVERSAL (ANTI-MACET)
    public static void showAd(final Activity activity, final Runnable afterAdAction) {
        if (isAdReady) {
            isAdReady = false;
            tampilkanIklanReward(activity, afterAdAction);
            return;
        }

        // Ganti baris Toast "Sedang memuat iklan..." di dalam showAd menjadi:
boolean initStatus = UnityAds.isInitialized();
Toast.makeText(activity.getApplicationContext(), "Memuat iklan... (Init: " + initStatus + ")", Toast.LENGTH_SHORT).show();
        isLoading = true;

        // Pengaman Timeout 8 detik agar tidak menggantung selamanya
        final Handler timeoutHandler = new Handler(Looper.getMainLooper());
        final boolean[] isHandled = {false};

        final Runnable timeoutRunnable = new Runnable() {
            @Override
            public void run() {
                if (!isHandled[0]) {
                    isHandled[0] = true;
                    isLoading = false;
                    Toast.makeText(activity.getApplicationContext(), "Iklan timeout, melanjutkan...", Toast.LENGTH_SHORT).show();
                    if (afterAdAction != null) afterAdAction.run();
                }
            }
        };
        timeoutHandler.postDelayed(timeoutRunnable, 8000);

        // Pastikan SDK sudah terinisialisasi sebelum memanggil load
        if (!UnityAds.isInitialized()) {
            UnityAds.initialize(activity.getApplicationContext(), UNITY_GAME_ID, TEST_MODE, new IUnityAdsInitializationListener() {
                @Override
                public void onInitializationComplete() {
                    if (!isHandled[0]) {
                        forceLoadAndShow(activity, afterAdAction, timeoutHandler, timeoutRunnable, isHandled);
                    }
                }

                @Override
                public void onInitializationFailed(UnityAds.UnityAdsInitializationError error, String message) {
                    if (!isHandled[0]) {
                        isHandled[0] = true;
                        timeoutHandler.removeCallbacks(timeoutRunnable);
                        isLoading = false;
                        Toast.makeText(activity.getApplicationContext(), "Init Gagal: " + error + " - " + message, Toast.LENGTH_LONG).show();
                        if (afterAdAction != null) afterAdAction.run();
                    }
                }
            });
        } else {
            forceLoadAndShow(activity, afterAdAction, timeoutHandler, timeoutRunnable, isHandled);
        }
    }

    private static void forceLoadAndShow(
            final Activity activity,
            final Runnable afterAdAction,
            final Handler timeoutHandler,
            final Runnable timeoutRunnable,
            final boolean[] isHandled
    ) {
        UnityAds.load(PLACEMENT_ID, new IUnityAdsLoadListener() {
            @Override
            public void onUnityAdsAdLoaded(String placementId) {
                if (isHandled[0]) return;
                isHandled[0] = true;
                timeoutHandler.removeCallbacks(timeoutRunnable);
                isLoading = false;
                isAdReady = false;

                if (!activity.isFinishing() && !activity.isDestroyed()) {
                    tampilkanIklanReward(activity, afterAdAction);
                }
            }

            @Override
            public void onUnityAdsFailedToLoad(String placementId, UnityAds.UnityAdsLoadError error, String message) {
                if (isHandled[0]) return;
                isHandled[0] = true;
                timeoutHandler.removeCallbacks(timeoutRunnable);
                isAdReady = false;
                isLoading = false;
                Toast.makeText(activity.getApplicationContext(), "Load Gagal: " + error + " - " + message, Toast.LENGTH_LONG).show();
                if (afterAdAction != null) afterAdAction.run();
            }
        });
    }

    private static void tampilkanIklanReward(final Activity activity, final Runnable afterAdAction) {
        UnityAds.show(activity, PLACEMENT_ID, new UnityAdsShowOptions(), new IUnityAdsShowListener() {
            @Override
            public void onUnityAdsShowFailure(String placementId, UnityAds.UnityAdsShowError error, String message) {
                loadAd(activity);
                Toast.makeText(activity.getApplicationContext(), "Show Gagal: " + error + " - " + message, Toast.LENGTH_SHORT).show();
                if (afterAdAction != null) afterAdAction.run();
            }

            @Override
            public void onUnityAdsShowStart(String placementId) {}

            @Override
            public void onUnityAdsShowClick(String placementId) {}

            @Override
            public void onUnityAdsShowComplete(String placementId, UnityAds.UnityAdsShowCompletionState state) {
                loadAd(activity);
                if (state == UnityAds.UnityAdsShowCompletionState.COMPLETED) {
                    if (afterAdAction != null) afterAdAction.run();
                } else {
                    Toast.makeText(activity.getApplicationContext(), "Tonton iklan sampai selesai untuk mengunduh.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
