package com.phoenix.tools.skin;

import android.app.Activity;
import android.widget.Toast;
import android.animation.ObjectAnimator;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.AndroidSketchwareMaster.ShizukuMaster;
import com.kaopiz.kprogresshud.KProgressHUD;

import java.io.File;

public class ShizukuHandler {

    private Activity activity;
    private ShizukuMaster shizuku;

    // ======================================
    // MODERN TOAST CONTROLLER
    // ======================================

    private final Handler toastHandler =
            new Handler(Looper.getMainLooper());

    private View activeToast;

    private ObjectAnimator progressAnimator;
    private ObjectAnimator mascotAnimator;

    private Runnable hideToastRunnable;

    // ======================================
    // CONSTRUCTOR
    // ======================================

    public ShizukuHandler(
            Activity activity,
            ShizukuMaster shizuku
    ) {
        this.activity = activity;
        this.shizuku = shizuku;
    }

    // ======================================
    // ACTIVITY SAFETY
    // ======================================

    private boolean isActivityAlive() {
        return activity != null
                && !activity.isFinishing()
                && !activity.isDestroyed();
    }

    private int dp(float value) {
        return (int) (
                value * activity.getResources()
                        .getDisplayMetrics().density + 0.5f
        );
    }

    // ======================================
    // CHECK FOLDER VIA SHIZUKU
    // ======================================

    private boolean shizukuFolderExists(String path) {
        try {
            String cmd =
                    "sh -c '[ -d \"" + path + "\" ] && echo YES || echo NO'";

            String result = shizuku.execCommand(cmd);

            return result != null && result.contains("YES");

        } catch (Exception e) {
            return false;
        }
    }

    // ======================================
    // AUTO DETECT ML PATH
    // ======================================

    private String getMlAssetsPath() {

        String[] packages = {
            "com.mobile.legends",
            "com.vng.mlbbvn",
            "com.mobile.legends.usa",
            "com.mobilelegends.mi",
            "com.mobilelegends.hwag",
            "com.moonton.dfjs",
            "com.mobile.legends.ft"
        };

        for (String pkg : packages) {

            String targetPath =
                    "/storage/emulated/0/Android/data/"
                    + pkg
                    + "/files/dragon2017/assets";

            if (shizukuFolderExists(targetPath)) {
                return targetPath;
            }
        }

        return null;
    }

    // ======================================
    // EXTRACT
    // ======================================

    public void extract(
            final String zipPath,
            final String assetsPath,
            final KProgressHUD hud
    ) {

        new Thread(new Runnable() {

            @Override
            public void run() {

                try {

                    final String targetPath;

                    if (assetsPath == null
                            || assetsPath.length() == 0) {

                        targetPath = getMlAssetsPath();

                    } else {

                        targetPath = assetsPath;
                    }

                    // ======================================
                    // FOLDER TIDAK DITEMUKAN
                    // ======================================

                    if (targetPath == null) {

                        activity.runOnUiThread(new Runnable() {

                            @Override
                            public void run() {

                                if (!isActivityAlive()) return;

                                if (hud != null && hud.isShowing()) {
                                    hud.dismiss();
                                }

                                Toast.makeText(
                                        activity,
                                        "Folder Mobile Legends tidak ditemukan!",
                                        Toast.LENGTH_LONG
                                ).show();
                            }
                        });

                        return;
                    }

                    // ======================================
                    // CEK ZIP
                    // ======================================

                    File zip = new File(zipPath);

                    if (!zip.exists()) {

                        activity.runOnUiThread(new Runnable() {

                            @Override
                            public void run() {

                                if (!isActivityAlive()) return;

                                if (hud != null && hud.isShowing()) {
                                    hud.dismiss();
                                }

                                Toast.makeText(
                                        activity,
                                        "ZIP tidak ditemukan!",
                                        Toast.LENGTH_LONG
                                ).show();
                            }
                        });

                        return;
                    }

                    // ======================================
                    // COMMAND EXTRACT
                    // ======================================

                    String command =
                            "mkdir -p \"" + targetPath
                            + "\" && unzip -o \"" + zipPath
                            + "\" -d \"" + targetPath + "\"";

                    final String result =
                            shizuku.execCommand(command);

                    // ======================================
                    // HASIL EXTRACT
                    // ======================================

                    activity.runOnUiThread(new Runnable() {

                        @Override
                        public void run() {

                            if (!isActivityAlive()) return;

                            if (hud != null && hud.isShowing()) {
                                hud.dismiss();
                            }

                            // RESET STATUS DOWNLOAD
                            try {

                                java.lang.reflect.Field field =
                                        ShizukuDownloader.class
                                                .getDeclaredField(
                                                        "isDownloading"
                                                );

                                field.setAccessible(true);
                                field.set(null, false);

                            } catch (Exception ignored) {
                            }

                            // ======================================
                            // HASIL BERHASIL
                            // ======================================

                            if (result != null) {

                                boolean deleted =
                                        new File(zipPath).delete();

                                showModernToast(
                                        "Success!",
                                        deleted
                                                ? "Skin berhasil di unduh & dipasang!"
                                                : "Skin terpasang, ZIP gagal dihapus"
                                );

                            } else {

                                Toast.makeText(
                                        activity,
                                        "Extract gagal ❌",
                                        Toast.LENGTH_LONG
                                ).show();
                            }
                        }
                    });

                } catch (final Exception e) {

                    activity.runOnUiThread(new Runnable() {

                        @Override
                        public void run() {

                            if (!isActivityAlive()) return;

                            if (hud != null && hud.isShowing()) {
                                hud.dismiss();
                            }

                            // RESET STATUS DOWNLOAD
                            try {

                                java.lang.reflect.Field field =
                                        ShizukuDownloader.class
                                                .getDeclaredField(
                                                        "isDownloading"
                                                );

                                field.setAccessible(true);
                                field.set(null, false);

                            } catch (Exception ignored) {
                            }

                            Toast.makeText(
                                    activity,
                                    "ERROR : " + e.getMessage(),
                                    Toast.LENGTH_LONG
                            ).show();
                        }
                    });
                }
            }
        }).start();
    }

    // ======================================
    // MODERN SUCCESS TOAST
    // ======================================

    private void showModernToast(
            String judul,
            String pesan
    ) {

        if (!isActivityAlive()) return;

        // HAPUS TOAST SEBELUMNYA
        removeActiveToast();

        final FrameLayout decorView =
                (FrameLayout) activity.getWindow().getDecorView();

        final View toastView =
                activity.getLayoutInflater().inflate(
                        R.layout.modern_toast,
                        null,
                        false
                );

        // ======================================
        // FIND VIEW
        // ======================================

        LinearLayout card_container =
                (LinearLayout) toastView.findViewById(
                        R.id.card_container
                );

        LinearLayout icon_bg =
                (LinearLayout) toastView.findViewById(
                        R.id.icon_bg
                );

        ImageView img_check =
                (ImageView) toastView.findViewById(
                        R.id.img_check
                );

        ImageView img_mascot =
                (ImageView) toastView.findViewById(
                        R.id.img_mascot
                );

        TextView txt_title =
                (TextView) toastView.findViewById(
                        R.id.txt_title
                );

        TextView txt_desc =
                (TextView) toastView.findViewById(
                        R.id.txt_desc
                );

        ProgressBar progress_timer =
                (ProgressBar) toastView.findViewById(
                        R.id.progress_timer
                );

        // ======================================
        // SET TEXT
        // ======================================

        txt_title.setText(judul);
        txt_desc.setText(pesan);

        // ======================================
        // CARD DESIGN
        // ======================================

        GradientDrawable bgCard = new GradientDrawable();

        bgCard.setColor(Color.parseColor("#000000"));
        bgCard.setCornerRadius(dp(28));

        bgCard.setStroke(
                dp(2),
                Color.parseColor("#76FF03")
        );

        card_container.setBackground(bgCard);
        card_container.setElevation(dp(16));

        // ======================================
        // SUCCESS ICON
        // ======================================

        GradientDrawable bgIcon = new GradientDrawable();

        bgIcon.setColor(Color.parseColor("#76FF03"));
        bgIcon.setShape(GradientDrawable.OVAL);

        icon_bg.setBackground(bgIcon);

        img_check.setColorFilter(
                Color.BLACK,
                PorterDuff.Mode.SRC_IN
        );

        // ======================================
        // MASCOT IMAGE
        // ======================================

        img_mascot.setImageResource(
                R.drawable.img_mascot
        );

        img_mascot.setVisibility(View.VISIBLE);
        img_mascot.setAlpha(0f);
        img_mascot.setTranslationY(dp(5));

        // ======================================
        // PROGRESS BAR
        // ======================================

        progress_timer.setIndeterminate(false);
        progress_timer.setMax(100);
        progress_timer.setProgress(100);

        if (progress_timer.getProgressDrawable() != null) {

            progress_timer.getProgressDrawable()
                    .mutate()
                    .setColorFilter(
                            Color.parseColor("#76FF03"),
                            PorterDuff.Mode.SRC_IN
                    );
        }

        // ======================================
        // LAYOUT
        // ======================================

        FrameLayout.LayoutParams params =
                new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                );

        params.gravity = Gravity.TOP;
        params.topMargin = dp(60);

        // ======================================
        // ADD TO WINDOW
        // ======================================

        try {

            decorView.addView(toastView, params);

            activeToast = toastView;

        } catch (Exception e) {

            return;
        }

        // ======================================
        // ENTRANCE ANIMATION
        // ======================================

        toastView.setTranslationY(-dp(300));
        toastView.setAlpha(0f);

        toastView.animate()
                .translationY(0f)
                .alpha(1f)
                .setDuration(400)
                .setInterpolator(
                        new DecelerateInterpolator()
                )
                .start();

        // ======================================
        // SUCCESS ICON BOUNCE
        // ======================================

        icon_bg.setScaleX(0f);
        icon_bg.setScaleY(0f);

        icon_bg.animate()
                .scaleX(1f)
                .scaleY(1f)
                .setStartDelay(150)
                .setDuration(450)
                .setInterpolator(
                        new OvershootInterpolator(2.5f)
                )
                .start();

        // ======================================
        // MASCOT FADE IN + FLOATING
        // ======================================

        img_mascot.animate()
                .alpha(1f)
                .translationY(0f)
                .setStartDelay(200)
                .setDuration(350)
                .withEndAction(new Runnable() {

                    @Override
                    public void run() {

                        if (activeToast != toastView) return;

                        mascotAnimator = ObjectAnimator.ofFloat(
                                img_mascot,
                                View.TRANSLATION_Y,
                                0f,
                                -dp(4),
                                0f
                        );

                        mascotAnimator.setDuration(1800);

                        mascotAnimator.setRepeatCount(
                                ObjectAnimator.INFINITE
                        );

                        mascotAnimator.setInterpolator(
                                new LinearInterpolator()
                        );

                        mascotAnimator.start();
                    }
                })
                .start();

        // ======================================
        // PROGRESS ANIMATION
        // ======================================

        progressAnimator = ObjectAnimator.ofInt(
                progress_timer,
                "progress",
                100,
                0
        );

        progressAnimator.setDuration(3000);

        progressAnimator.setInterpolator(
                new LinearInterpolator()
        );

        progressAnimator.start();

        // ======================================
        // AUTO DISMISS
        // ======================================

        hideToastRunnable = new Runnable() {

            @Override
            public void run() {

                if (activeToast != toastView) return;

                if (!isActivityAlive()) {

                    removeActiveToast();
                    return;
                }

                toastView.animate()
                        .translationY(-dp(300))
                        .alpha(0f)
                        .setDuration(350)
                        .withEndAction(new Runnable() {

                            @Override
                            public void run() {

                                if (activeToast == toastView) {
                                    removeActiveToast();
                                }
                            }
                        })
                        .start();
            }
        };

        toastHandler.postDelayed(
                hideToastRunnable,
                3000
        );
    }

    // ======================================
    // REMOVE ACTIVE TOAST
    // ======================================

    private void removeActiveToast() {

        // BATALKAN CALLBACK TOAST
        if (hideToastRunnable != null) {

            toastHandler.removeCallbacks(
                    hideToastRunnable
            );

            hideToastRunnable = null;
        }

        // HENTIKAN PROGRESS ANIMATOR
        if (progressAnimator != null) {

            progressAnimator.cancel();
            progressAnimator = null;
        }

        // HENTIKAN ANIMASI MASKOT
        if (mascotAnimator != null) {

            mascotAnimator.cancel();
            mascotAnimator = null;
        }

        // HAPUS TOAST DARI WINDOW
        if (activeToast != null) {

            View oldToast = activeToast;
            activeToast = null;

            oldToast.animate().cancel();

            if (oldToast.getParent() instanceof ViewGroup) {

                try {

                    ((ViewGroup) oldToast.getParent())
                            .removeView(oldToast);

                } catch (Exception e) {
                }
            }
        }
    }

    // ======================================
    // CLEANUP ACTIVITY
    // ======================================

    public void cleanup() {

        removeActiveToast();
    }
}
